#!/usr/bin/env bash
# Offline-only verification; no Minecraft classes, Gradle or network required.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAIN="$ROOT/src/main/java/dev/dalmacc/godbridge"
TEST="$ROOT/src/test/java/dev/dalmacc/godbridge"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -encoding UTF-8 -d "$OUT" \
  "$MAIN/ClickEvaluation.java" "$MAIN/PlacementEvidence.java" "$MAIN/PulseDelivery.java" "$MAIN/MetronomeRecovery.java" "$MAIN/MetronomeTimeline.java" "$MAIN/PlacementStreaks.java" "$MAIN/RhythmMath.java" "$MAIN/BeatConsistency.java" "$MAIN/CadenceTracker.java" "$MAIN/TempoMatcher.java" "$MAIN/AttemptHistory.java" \
  "$MAIN/SessionExporter.java" "$MAIN/TrainingAdvisor.java" "$MAIN/AimHistory.java" \
  "$MAIN/AngleMath.java" "$MAIN/ScreenAimDirection.java" "$MAIN/AimCalibrator.java" "$TEST/ScreenAimDirectionSelfTest.java" "$TEST/RhythmMathSelfTest.java" \
  "$TEST/RhythmSubdivisionSelfTest.java" "$TEST/MetronomeTimelineSelfTest.java" "$TEST/CadenceTrackerSelfTest.java" "$TEST/TempoMatcherSelfTest.java" "$TEST/BeatConsistencySelfTest.java" \
  "$TEST/AttemptHistorySelfTest.java" "$TEST/PlacementEvidenceSelfTest.java" "$TEST/PlacementStreaksSelfTest.java" "$TEST/ClickEvaluationSelfTest.java" "$TEST/PulseDeliverySelfTest.java" "$TEST/RenderCadenceSelfTest.java" "$TEST/MetronomeRecoverySelfTest.java" "$TEST/AimCalibratorSelfTest.java"
for test in ClickEvaluationSelfTest AimCalibratorSelfTest PlacementStreaksSelfTest PulseDeliverySelfTest RenderCadenceSelfTest MetronomeRecoverySelfTest ScreenAimDirectionSelfTest RhythmMathSelfTest MetronomeTimelineSelfTest RhythmSubdivisionSelfTest CadenceTrackerSelfTest TempoMatcherSelfTest BeatConsistencySelfTest AttemptHistorySelfTest PlacementEvidenceSelfTest; do
  java -cp "$OUT" "dev.dalmacc.godbridge.$test"
done
echo 'Pure Java verification passed. This is NOT a Minecraft/Fabric build.'
