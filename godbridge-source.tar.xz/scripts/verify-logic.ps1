$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$main = Join-Path $root 'src/main/java/dev/dalmacc/godbridge'
$test = Join-Path $root 'src/test/java/dev/dalmacc/godbridge'
$out = Join-Path ([System.IO.Path]::GetTempPath()) ('godbridge-verify-' + [guid]::NewGuid())
New-Item -ItemType Directory -Path $out -Force | Out-Null
try {
    $sources = @(
        'ClickEvaluation.java', 'PlacementEvidence.java', 'PlacementStreaks.java', 'PulseDelivery.java', 'MetronomeRecovery.java', 'MetronomeTimeline.java', 'RhythmMath.java', 'BeatConsistency.java', 'CadenceTracker.java', 'TempoMatcher.java', 'AttemptHistory.java',
        'SessionExporter.java', 'TrainingAdvisor.java', 'AimHistory.java', 'AngleMath.java', 'ScreenAimDirection.java', 'AimCalibrator.java'
    ) | ForEach-Object { Join-Path $main $_ }
    $tests = @('RhythmMathSelfTest.java','RhythmSubdivisionSelfTest.java','MetronomeTimelineSelfTest.java',
        'CadenceTrackerSelfTest.java','TempoMatcherSelfTest.java','ScreenAimDirectionSelfTest.java','BeatConsistencySelfTest.java','AttemptHistorySelfTest.java','PlacementEvidenceSelfTest.java','AimCalibratorSelfTest.java','PlacementStreaksSelfTest.java','PulseDeliverySelfTest.java','RenderCadenceSelfTest.java','MetronomeRecoverySelfTest.java','ClickEvaluationSelfTest.java')
    $sources += $tests | ForEach-Object { Join-Path $test $_ }
    & javac -encoding UTF-8 -d $out @sources
    if ($LASTEXITCODE -ne 0) { throw 'Offline javac failed.' }
    foreach ($name in $tests) {
        $className = 'dev.dalmacc.godbridge.' + $name.Replace('.java', '')
        & java -cp $out $className
        if ($LASTEXITCODE -ne 0) { throw "Test failed: $className" }
    }
    Write-Host 'Pure Java verification passed. This is NOT a Minecraft/Fabric build.'
} finally {
    Remove-Item -Recurse -Force $out -ErrorAction SilentlyContinue
}
