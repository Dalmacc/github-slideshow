$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$gradleVersion = '9.7.1'
$gradleSha256 = 'acd53f1edaf02f1a8ff99879f8a34b302661a057d9b063ae9e35b552f804d20a'
# `java -version` writes to stderr, which Windows PowerShell 5.1 may
# incorrectly treat as a terminating error under Stop. --version uses stdout.
if (-not (Get-Command java -ErrorAction SilentlyContinue) -or
    -not (Get-Command javac -ErrorAction SilentlyContinue)) {
    throw 'JDK 25 is required: java and javac must both be available on PATH.'
}
$javaVersion = ((& java --version | Select-Object -First 1) -join '').Trim()
$javacVersion = ((& javac -version | Select-Object -First 1) -join '').Trim()
if ($javaVersion -notmatch '^(?:openjdk|java) 25(?:[.\s+]|$)' -or
    $javacVersion -notmatch '^javac 25(?:[.\s+]|$)') {
    throw "JDK 25 (java + javac) is required. Found: $javaVersion / $javacVersion"
}
$installedGradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($installedGradle) {
    $gradleExe = $installedGradle.Source
} else {
    $localDir = Join-Path $PSScriptRoot '.local-gradle'
    $gradleExe = Join-Path $localDir "gradle-$gradleVersion/bin/gradle.bat"
    if (-not (Test-Path $gradleExe)) {
        New-Item -ItemType Directory -Force -Path $localDir | Out-Null
        $zip = Join-Path $localDir "gradle-$gradleVersion.zip"
        try {
            Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip" -OutFile $zip
            $actual = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLowerInvariant()
            if ($actual -ne $gradleSha256) { throw "Gradle download checksum mismatch: $actual" }
            Expand-Archive -Path $zip -DestinationPath $localDir -Force
        } finally {
            Remove-Item $zip -Force -ErrorAction SilentlyContinue
        }
    }
}
# PowerShell 5.1 wraps *native stderr* as a NativeCommandError when
# ErrorActionPreference=Stop. That is not a Gradle failure. Capture both
# streams, preserve the actual process exit code, and restore the preference.
$previousPreference = $ErrorActionPreference
try {
    $ErrorActionPreference = 'Continue'
    & $gradleExe --no-daemon --stacktrace clean build 2>&1 |
        ForEach-Object { $_.ToString() } |
        Tee-Object -FilePath (Join-Path $PSScriptRoot 'gradle-build.log')
    $gradleExitCode = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousPreference
}
if ($gradleExitCode -ne 0) { throw "Gradle build failed ($gradleExitCode). See gradle-build.log" }
$jar = Join-Path $PSScriptRoot 'build/libs/godbridge-trainer-26.3-0.14.0.jar'
if (-not (Test-Path $jar)) { throw "Build passed but expected JAR is missing: $jar" }
$entries = & jar tf $jar
if ($LASTEXITCODE -ne 0 -or ($entries -notcontains 'fabric.mod.json') -or
    ($entries -notcontains 'dev/dalmacc/godbridge/GodBridgeTrainerClient.class')) {
    throw 'JAR is invalid or missing Fabric metadata / client class'
}
Write-Host "Built: $jar"
