#!/usr/bin/env bash
# Builds with JDK 25 without modifying the host JDK.
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then
  echo 'Docker is required for the optional container build.' >&2
  exit 1
fi
IMAGE='godbridge-trainer-builder:0.13'
docker build -t "$IMAGE" -f Dockerfile .
docker run --rm --user "$(id -u):$(id -g)" \
  --mount "type=bind,source=$(pwd),target=/work" \
  --env GRADLE_USER_HOME=/work/.gradle-user-home \
  --workdir /work "$IMAGE"
echo 'Check build/libs/ for the produced mod JAR.'
