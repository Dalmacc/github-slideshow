# Настоящая сборка (14.10.2026)

- CI: https://github.com/Dalmacc/github-slideshow/actions/runs/38512183020
  Ошибка `modImplementation` в новом необфусцированном Loom.
- CI: https://github.com/Dalmacc/github-slideshow/actions/runs/38512340784
  Успешно прошли `compileJava`, `compileTestJava`, `jar`, `assemble`. `test` прерван по причине отсутствия JUnit test discovery (есть JavaExec self-tests).
- Для третьей сборки применяется `implementation` и отключение JUnit `test`; `verifyLogic` по-прежнему запускает 17 JavaExec проверок.

**Успех полной сборки пока не подтвержден; игровые проверки не проводились.**
