# Optional local build without installing JDK 25 on Windows.
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path $PSScriptRoot).Path
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Docker Desktop with Linux containers is required for this optional build.'
}
$image = 'godbridge-trainer-builder:0.13'
& docker build -t $image -f (Join-Path $project 'Dockerfile') $project
if ($LASTEXITCODE -ne 0) { throw 'Could not build the JDK 25 container image.' }
& docker run --rm --mount "type=bind,source=$project,target=/work" `
    --env GRADLE_USER_HOME=/work/.gradle-user-home --workdir /work $image
if ($LASTEXITCODE -ne 0) { throw 'Real Fabric/Gradle build failed. Inspect gradle-build.log.' }
Write-Host 'Check build/libs/ for the produced mod JAR.'
