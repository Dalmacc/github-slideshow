package dev.dalmacc.godbridge;

/**
 * Converts the projected screen position of a world-space target into a
 * correction relative to the actual crosshair. No Minecraft dependencies:
 * the sign is screen-space rather than block-face-space, so oblique camera
 * angles and the four possible side faces cannot invert the advice.
 */
public final class ScreenAimDirection {
    private ScreenAimDirection() {}

    public enum Cue {
        CENTERED("ПО ЦЕНТРУ"),
        UP("↑ ВЫШЕ"), DOWN("↓ НИЖЕ"),
        LEFT("← ЛЕВЕЕ"), RIGHT("→ ПРАВЕЕ"),
        UP_LEFT("↖ ВЫШЕ И ЛЕВЕЕ"), UP_RIGHT("↗ ВЫШЕ И ПРАВЕЕ"),
        DOWN_LEFT("↙ НИЖЕ И ЛЕВЕЕ"), DOWN_RIGHT("↘ НИЖЕ И ПРАВЕЕ");

        private final String text;
        Cue(String text) { this.text = text; }
        public String text() { return text; }
    }

    /**
     * @param targetX projected world point in GUI pixel coordinates
     * @param targetY projected world point in GUI pixel coordinates
     * @param centerX crosshair x in GUI pixel coordinates
     * @param centerY crosshair y in GUI pixel coordinates
     * @param deadZonePx per-axis dead zone to prevent jitter near the center
     */
    public static Cue cue(double targetX, double targetY, double centerX, double centerY,
                          double deadZonePx) {
        if (!Double.isFinite(targetX) || !Double.isFinite(targetY)
                || !Double.isFinite(centerX) || !Double.isFinite(centerY)
                || !Double.isFinite(deadZonePx) || deadZonePx < 0)
            throw new IllegalArgumentException("Invalid screen point or dead zone");
        int horizontal = targetX < centerX - deadZonePx ? -1 : targetX > centerX + deadZonePx ? 1 : 0;
        int vertical = targetY < centerY - deadZonePx ? -1 : targetY > centerY + deadZonePx ? 1 : 0;
        if (vertical < 0) return horizontal < 0 ? Cue.UP_LEFT : horizontal > 0 ? Cue.UP_RIGHT : Cue.UP;
        if (vertical > 0) return horizontal < 0 ? Cue.DOWN_LEFT : horizontal > 0 ? Cue.DOWN_RIGHT : Cue.DOWN;
        return horizontal < 0 ? Cue.LEFT : horizontal > 0 ? Cue.RIGHT : Cue.CENTERED;
    }
}
