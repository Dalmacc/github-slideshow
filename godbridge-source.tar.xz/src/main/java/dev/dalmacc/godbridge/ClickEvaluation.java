package dev.dalmacc.godbridge;

/**
 * Immutable training rules captured with the actual physical mouse press.
 * They deliberately do NOT reference mutable TrainerConfig or Minecraft APIs.
 * An asynchronous placement confirmation cannot retroactively change the
 * target position, rhythm quality, or aim tolerance used to grade that click.
 */
public record ClickEvaluation(boolean metronome, int bpm, int subdivisions,
                              int timingToleranceMs, double guideLateral,
                              double guideHeight, double aimTolerance) {
    public enum Issue { NONE, EARLY, LATE, AIM }

    public ClickEvaluation {
        RhythmMath.clickPeriodNs(bpm, subdivisions);
        if (timingToleranceMs < 1 || !Double.isFinite(guideLateral) || !Double.isFinite(guideHeight)
                || !Double.isFinite(aimTolerance) || aimTolerance <= 0)
            throw new IllegalArgumentException("Invalid captured click criteria");
    }

    public boolean offTarget(double aimError) {
        return Double.isFinite(aimError) && aimError > aimTolerance;
    }

    public Issue evaluate(int timingErrorMs, double aimError) {
        if (metronome && Math.abs((long) timingErrorMs) >
                RhythmMath.effectiveToleranceMs(bpm, timingToleranceMs, subdivisions)) {
            return timingErrorMs < 0 ? Issue.EARLY : Issue.LATE;
        }
        return offTarget(aimError) ? Issue.AIM : Issue.NONE;
    }
}
