package dev.dalmacc.godbridge;

/**
 * Rebuilds a streak in INPUT order, never in the order delayed confirmations arrive.
 * Unknown outcomes are neutral; unresolved older clicks split proven chains until resolved.
 */
public final class PlacementStreaks {
    private PlacementStreaks() {}

    public record Snapshot(int current, int longest) {}

    public static Snapshot evaluate(Iterable<AttemptHistory.Entry> attempts, int afterSerial) {
        int current = 0;
        int longest = 0;
        for (AttemptHistory.Entry entry : attempts) {
            if (entry.serial <= afterSerial) continue;
            switch (entry.outcome()) {
                case PLACED -> {
                    current++;
                    longest = Math.max(longest, current);
                }
                case PENDING, NO_BLOCKS, MISS, WRONG_FACE, OCCUPIED, DUPLICATE -> current = 0;
                case CANCELED, TIMEOUT, OTHER_BLOCK, OVERLAP -> {
                    // No proof of a player mistake; keep the proven sequence intact.
                }
            }
        }
        return new Snapshot(current, longest);
    }
}
