package dev.dalmacc.godbridge;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Settings are stored locally; this mod does not require a server companion. */
public final class TrainerConfig {
    public boolean hud = true;
    public boolean targetMarker = true;
    public boolean metronome = true;
    public boolean metronomeSound = true;
    public boolean feedback = true;
    public boolean diagonalHint = true;
    public boolean heatmap = true;
    public boolean angleHint = true;
    public int bpm = 260;
    /** 1..4 clicks per metronome quarter-note; four at 260 BPM = 17.33 CPS. */
    public int subdivisions = 4;
    /** 0=hat, 1=bass drum, 2=bell. */
    public int soundStyle = 0;
    /** Physical-click grading correction (latency), without shifting the sound. */
    public int beatOffsetMs = 0;
    /** Independent delay/advance for audible pulses. Defaults to zero for existing users. */
    public int audioOffsetMs = 0;
    public int timingToleranceMs = 65;
    public double aimTolerance = 0.12;
    public double guideHeight = GuideTarget.DEFAULT_HEIGHT;
    public double guideLateral = GuideTarget.DEFAULT_LATERAL;
    private final Path path;

    private TrainerConfig(Path path) {
        this.path = path;
    }

    public static TrainerConfig load() {
        TrainerConfig cfg = new TrainerConfig(FabricLoader.getInstance().getConfigDir().resolve("godbridge_trainer.properties"));
        Properties values = new Properties();
        if (Files.isRegularFile(cfg.path)) {
            try (InputStream stream = Files.newInputStream(cfg.path)) {
                values.load(stream);
                cfg.hud = bool(values, "hud", cfg.hud);
                cfg.targetMarker = bool(values, "targetMarker", cfg.targetMarker);
                cfg.metronome = bool(values, "metronome", cfg.metronome);
                cfg.metronomeSound = bool(values, "metronomeSound", cfg.metronomeSound);
                cfg.feedback = bool(values, "feedback", cfg.feedback);
                cfg.diagonalHint = bool(values, "diagonalHint", cfg.diagonalHint);
                cfg.heatmap = bool(values, "heatmap", cfg.heatmap);
                cfg.angleHint = bool(values, "angleHint", cfg.angleHint);
                cfg.bpm = clamp(number(values, "bpm", cfg.bpm), 100, 600);
                // Old v0.3 config had one click per beat; preserve that rhythm on upgrade.
                cfg.subdivisions = clamp(number(values, "subdivisions", 1), 1, 4);
                cfg.soundStyle = clamp(number(values, "soundStyle", cfg.soundStyle), 0, 2);
                cfg.beatOffsetMs = clamp(number(values, "beatOffsetMs", cfg.beatOffsetMs), -200, 200);
                cfg.audioOffsetMs = clamp(number(values, "audioOffsetMs", cfg.audioOffsetMs), -200, 200);
                cfg.timingToleranceMs = clamp(number(values, "timingToleranceMs", cfg.timingToleranceMs), 20, 200);
                cfg.aimTolerance = Math.clamp(decimal(values, "aimTolerance", cfg.aimTolerance), 0.05, 0.45);
                cfg.guideHeight = Math.clamp(decimal(values, "guideHeight", cfg.guideHeight), 0.70, 0.99);
                cfg.guideLateral = Math.clamp(decimal(values, "guideLateral", cfg.guideLateral), 0.10, 0.90);
            } catch (IOException ignored) {
                // Preserve usable defaults even if the settings file is damaged.
            }
        }
        return cfg;
    }

    public void save() {
        Properties values = new Properties();
        values.setProperty("hud", Boolean.toString(hud));
        values.setProperty("targetMarker", Boolean.toString(targetMarker));
        values.setProperty("metronome", Boolean.toString(metronome));
        values.setProperty("metronomeSound", Boolean.toString(metronomeSound));
        values.setProperty("feedback", Boolean.toString(feedback));
        values.setProperty("diagonalHint", Boolean.toString(diagonalHint));
        values.setProperty("heatmap", Boolean.toString(heatmap));
        values.setProperty("angleHint", Boolean.toString(angleHint));
        values.setProperty("bpm", Integer.toString(bpm));
        values.setProperty("subdivisions", Integer.toString(subdivisions));
        values.setProperty("soundStyle", Integer.toString(soundStyle));
        values.setProperty("beatOffsetMs", Integer.toString(beatOffsetMs));
        values.setProperty("audioOffsetMs", Integer.toString(audioOffsetMs));
        values.setProperty("timingToleranceMs", Integer.toString(timingToleranceMs));
        values.setProperty("aimTolerance", Double.toString(aimTolerance));
        values.setProperty("guideHeight", Double.toString(guideHeight));
        values.setProperty("guideLateral", Double.toString(guideLateral));
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream stream = Files.newOutputStream(path)) {
                values.store(stream, "GodBridge Trainer - Fabric 26.3");
            }
        } catch (IOException ignored) {
            // A read-only configuration directory should not crash the game.
        }
    }

    private static int number(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, "")); }
        catch (NumberFormatException ex) { return fallback; }
    }

    private static double decimal(Properties p, String key, double fallback) {
        try {
            double parsed = Double.parseDouble(p.getProperty(key, ""));
            return Double.isFinite(parsed) ? parsed : fallback;
        } catch (NumberFormatException ex) { return fallback; }
    }

    private static boolean bool(Properties p, String key, boolean fallback) {
        return Boolean.parseBoolean(p.getProperty(key, Boolean.toString(fallback)));
    }

    public static int clamp(int value, int lo, int hi) {
        return Math.max(lo, Math.min(hi, value));
    }
}
