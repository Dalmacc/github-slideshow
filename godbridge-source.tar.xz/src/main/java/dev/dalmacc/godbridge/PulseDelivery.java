package dev.dalmacc.godbridge;

import java.util.ArrayDeque;

/**
 * Detects audio metronome pulses skipped because world render frames couldn't keep up.
 * Counts only changes to the beat index; a long pause is treated as a resync,
 * not as thousands of dropped sounds. No thread, input automation or audio timer.
 */
public final class PulseDelivery {
    private static final int WINDOW = 32;
    private static final int LONG_GAP = 16;
    private final ArrayDeque<Integer> skipped = new ArrayDeque<>();
    private long lastIndex = Long.MIN_VALUE;
    private int missedTotal;

    /** Has the sound stream received an initial slot yet? */
    public boolean isUninitialized() { return lastIndex == Long.MIN_VALUE; }

    /** Arm a shifted timeline without emitting a phantom pulse in the middle of a slot. */
    public void prime(long index) {
        clear();
        lastIndex = index;
    }

    /** True if one click/pulse should be played in this render frame. */
    public boolean advance(long index) {
        if (lastIndex == index) return false;
        if (lastIndex == Long.MIN_VALUE || index < lastIndex || index - lastIndex > LONG_GAP) {
            clear();
            lastIndex = index;
            add(0);
            return true;
        }
        int dropped = (int) (index - lastIndex - 1);
        lastIndex = index;
        add(dropped);
        return true;
    }

    private void add(int missed) {
        if (skipped.size() == WINDOW) missedTotal -= skipped.removeFirst();
        skipped.addLast(missed);
        missedTotal += missed;
    }

    public Snapshot snapshot() {
        int renderedPulses = skipped.size();
        return new Snapshot(renderedPulses, missedTotal);
    }

    public void clear() {
        skipped.clear();
        missedTotal = 0;
        lastIndex = Long.MIN_VALUE;
    }

    public record Snapshot(int renderedPulses, int missedPulses) {
        public int missPercent() {
            int total = renderedPulses + missedPulses;
            return total == 0 ? 0 : (int) Math.round(100.0 * missedPulses / total);
        }
        public boolean frameLimited() {
            return renderedPulses >= 6 && missedPulses >= 3 && missPercent() >= 15;
        }
    }
}
