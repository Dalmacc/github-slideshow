package dev.dalmacc.godbridge;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/** A ray-testable training point on the exposed face of a full block. */
public record GuideTarget(BlockPos anchor, Direction face, Vec3 point) {
    public static final double DEFAULT_HEIGHT = 0.96875;
    public static final double DEFAULT_LATERAL = 0.5;

    public BlockPos destination() { return anchor.relative(face); }

    public static Vec3 guidePoint(BlockPos anchor, Direction face, double u, double v) {
        if (face.getAxis() == Direction.Axis.Y) throw new IllegalArgumentException("Requires a side face");
        u = Math.clamp(u, 0.01, 0.99);
        v = Math.clamp(v, 0.01, 0.99);
        // Exactly invert faceU(). All four directions share a camera-left -> camera-right scale.
        double across = (face == Direction.NORTH || face == Direction.EAST) ? 1.0 - u : u;
        double x = face.getStepX() != 0 ? anchor.getX() + 0.5 + face.getStepX() * 0.5 : anchor.getX() + across;
        double z = face.getStepZ() != 0 ? anchor.getZ() + 0.5 + face.getStepZ() * 0.5 : anchor.getZ() + across;
        return new Vec3(x, anchor.getY() + v, z);
    }

    public static double planarError(Vec3 actual, BlockPos anchor, Direction face, double u, double v) {
        return Math.hypot(faceU(actual, anchor, face) - u,
                faceV(actual, anchor) - v);
    }

    /** Screen-left to screen-right coordinate on a clicked vertical face, normalized 0..1. */
    public static double faceU(Vec3 hit, BlockPos anchor, Direction face) {
        double across = face.getStepX() != 0 ? hit.z - anchor.getZ() : hit.x - anchor.getX();
        return face == Direction.NORTH || face == Direction.EAST ? 1.0 - across : across;
    }

    public static double faceV(Vec3 hit, BlockPos anchor) {
        return hit.y - anchor.getY();
    }
}
