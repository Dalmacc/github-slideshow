package dev.dalmacc.godbridge;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** No placement automation. Every score comes from real user input + world changes. */
public final class BridgeCoach {
    public final TrainerConfig cfg;
    public final AimHistory aimHistory = new AimHistory();
    public final AimCalibrator aimCalibrator = new AimCalibrator();
    public final CadenceTracker cadence = new CadenceTracker();
    public final TempoMatcher tempoMatcher = new TempoMatcher();
    public final BeatConsistency beatConsistency = new BeatConsistency();
    public final PulseDelivery pulseDelivery = new PulseDelivery();
    public final MetronomeRecovery renderRecovery = new MetronomeRecovery();
    /** Frames stalled long enough to need a fresh audible downbeat. */
    public int metronomeResyncs;
    public final AttemptHistory attemptHistory = new AttemptHistory();
    public boolean active;
    public int rightClicks;
    public int successfulBlocks;
    public int failedClicks;
    /** Network/server-disputed clicks; not counted as confirmed player mistakes. */
    public int unconfirmedClicks;
    public int duplicateClicks;
    public int offTarget;
    public int earlyClicks;
    public int lateClicks;
    public int falls;
    public int streak;
    public int bestStreak;
    public int lastErrorMs;
    public int peakCps;
    public String feedback = "F8 — начать тренировку";
    public int feedbackColor = 0xFFE4EAF8;
    public GuideTarget target;
    public long beatOriginNs;
    public long lastFeedbackNs;

    private final ArrayDeque<Long> clickTimes = new ArrayDeque<>();
    private final ArrayDeque<Integer> recentTimingErrors = new ArrayDeque<>();
    private final List<Pending> pending = new ArrayList<>();
    private int streakEpochStartSerial;
    private boolean pausedByGui;
    private double lastSafeY = Double.NaN;
    private boolean fallReported;
    private net.minecraft.world.level.Level currentWorld;
    private int targetScanTicks;
    // Wait up to 1.5 seconds for a server/client world update before concluding a placement is missing.
    private static final int PLACEMENT_TIMEOUT_TICKS = 30;
    private static final int MAX_PENDING = 64;
    private static final int STABLE_PLACEMENT_TICKS = 2;

    public BridgeCoach(TrainerConfig cfg) {
        this.cfg = cfg;
    }

    public void toggle() {
        active = !active;
        discardPending();
        target = null;
        lastSafeY = Double.NaN;
        fallReported = false;
        clickTimes.clear();
        cadence.clear();
        if (active) tempoMatcher.clear();
        beatConsistency.clear();
        pulseDelivery.clear();
        renderRecovery.clear();
        metronomeResyncs = 0;
        streakEpochStartSerial = attemptHistory.latestSerial();
        streak = 0;
        pausedByGui = false;
        targetScanTicks = 0;
        if (active) {
            beatOriginNs = System.nanoTime();
            feedback = "Двигайся назад по диагонали (S+A или S+D)";
            feedbackColor = 0xFFE0EDFF;
        } else {
            feedback = "Тренировка приостановлена";
        }
        lastFeedbackNs = System.nanoTime();
    }

    /** Keep the first beat predictable after changing the tempo in the settings. */
    public void resyncBeat() {
        pausedByGui = false;
        beatOriginNs = System.nanoTime();
        pulseDelivery.clear();
        renderRecovery.clear();
        beatConsistency.clear();
    }

    public void reset() {
        rightClicks = successfulBlocks = failedClicks = unconfirmedClicks = duplicateClicks = offTarget = 0;
        earlyClicks = lateClicks = falls = streak = bestStreak = peakCps = lastErrorMs = 0;
        discardPending();
        aimHistory.clear();
        aimCalibrator.clear();
        attemptHistory.clear();
        recentTimingErrors.clear();
        clickTimes.clear();
        cadence.clear();
        tempoMatcher.clear();
        beatConsistency.clear();
        beatOriginNs = System.nanoTime();
        streakEpochStartSerial = 0;
        pausedByGui = false;
        pulseDelivery.clear();
        renderRecovery.clear();
        metronomeResyncs = 0;
        feedback = "Статистика сброшена";
        feedbackColor = 0xFFE0EDFF;
        lastFeedbackNs = System.nanoTime();
    }

    public void onRawRightClick(Minecraft mc, long whenNs) {
        if (!active || mc.player == null || mc.level == null || mc.gui.screen() != null) return;
        ensureWorld(mc);
        rightClicks++;
        clickTimes.addLast(whenNs);
        cadence.record(whenNs);
        tempoMatcher.record(whenNs);
        pruneOldClicks(whenNs);
        peakCps = Math.max(peakCps, clickTimes.size());
        lastErrorMs = cfg.metronome ? RhythmMath.signedErrorMs(whenNs, beatOriginNs,
                cfg.bpm, cfg.beatOffsetMs, cfg.subdivisions) : 0;
        if (cfg.metronome) {
            beatConsistency.record(whenNs, beatOriginNs, cfg.bpm, cfg.subdivisions,
                    cfg.beatOffsetMs, cfg.timingToleranceMs);
            recentTimingErrors.addLast(Math.abs(lastErrorMs));
            if (recentTimingErrors.size() > 32) recentTimingErrors.removeFirst();
            int tolerance = RhythmMath.effectiveToleranceMs(cfg.bpm, cfg.timingToleranceMs, cfg.subdivisions);
            if (lastErrorMs < -tolerance) earlyClicks++;
            if (lastErrorMs > tolerance) lateClicks++;
        }

        double angleAtClick = angleError(mc);
        boolean diagonalAtClick = diagonalKeys(mc);
        AttemptHistory.Entry log = attemptHistory.begin(whenNs, cfg.bpm, cfg.subdivisions, lastErrorMs, cfg.metronome,
                diagonalAtClick, angleAtClick, cfg.beatOffsetMs, cfg.audioOffsetMs);
        attemptHistory.recordCriteria(log, cfg.timingToleranceMs, cfg.aimTolerance);
        Block mainBlock = mc.player.getMainHandItem().getItem() instanceof BlockItem item
                ? item.getBlock() : null;
        Block offBlock = mc.player.getOffhandItem().getItem() instanceof BlockItem item
                ? item.getBlock() : null;
        if (mainBlock == null && offBlock == null) {
            fail(log, AttemptHistory.Outcome.NO_BLOCKS, "Возьми строительные блоки в руку");
            return;
        }
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            fail(log, AttemptHistory.Outcome.MISS, "Промах: прицел не попал в блок");
            return;
        }
        Direction side = hit.getDirection();
        if (side == Direction.UP || side == Direction.DOWN) {
            fail(log, AttemptHistory.Outcome.WRONG_FACE,
                    side == Direction.UP ? "Неверная грань: попал сверху" : "Неверная грань: попал снизу");
            return;
        }
        double u = GuideTarget.faceU(hit.getLocation(), hit.getBlockPos(), side);
        double v = GuideTarget.faceV(hit.getLocation(), hit.getBlockPos());
        double aimError = GuideTarget.planarError(hit.getLocation(), hit.getBlockPos(), side,
                cfg.guideLateral, cfg.guideHeight);
        attemptHistory.recordAim(log, u, v, aimError);
        AimHistory.Sample aimSample = aimHistory.record(u, v);
        boolean highlightedFace = target != null && target.anchor().equals(hit.getBlockPos())
                && target.face() == side;
        BlockPos toPlace = hit.getBlockPos().relative(side);
        if (!mc.level.getBlockState(toPlace).canBeReplaced()) {
            aimHistory.resolve(aimSample, false);
            fail(log, AttemptHistory.Outcome.OCCUPIED, "Место перед гранью уже занято");
            return;
        }
        for (Pending shot : pending) {
            if (shot.destination.equals(toPlace)) {
                // A high-CPS physical click can arrive before the server/client world
                // acknowledges the previous placement. This is NOT evidence of a
                // failed placement or poor aim; leave it out of the success denominator.
                aimHistory.cancel(aimSample);
                duplicateClicks++;
                attemptHistory.resolve(log, AttemptHistory.Outcome.OVERLAP, -1);
                if (cfg.feedback) setFeedback("ПКМ до подтверждения предыдущего блока", 0xFFFFD36C);
                return;
            }
        }
        // Snapshot ALL evaluation criteria at input time. Client/server updates may
        // arrive after the player has edited F9 settings; old clicks must not be
        // re-scored against a new rhythm tolerance or a relocated guide target.
        ClickEvaluation evaluation = new ClickEvaluation(cfg.metronome, cfg.bpm, cfg.subdivisions,
                cfg.timingToleranceMs, cfg.guideLateral, cfg.guideHeight, cfg.aimTolerance);
        pending.add(new Pending(hit.getBlockPos().immutable(), side, toPlace.immutable(), hit.getLocation(),
                aimSample, log, whenNs, lastErrorMs, angleAtClick, diagonalAtClick,
                mc.player.getLookAngle(), mainBlock, offBlock, highlightedFace, evaluation));
        if (pending.size() > MAX_PENDING) {
            Pending oldest = pending.removeFirst();
            unconfirmed(oldest, "Слишком много непроверенных кликов");
        }
    }

    public void tick(Minecraft mc) {
        if (!active) return;
        if (mc.player == null || mc.level == null) {
            discardPending();
            target = null;
            currentWorld = null;
            return;
        }
        ensureWorld(mc);
        // Pause the beat phase in ANY vanilla or mod GUI, not only our F9 screen.
        boolean guiOpen = mc.gui.screen() != null;
        if (guiOpen) pausedByGui = true;
        else if (pausedByGui) {
            pausedByGui = false;
            resyncBeat();
        }

        for (Iterator<Pending> it = pending.iterator(); it.hasNext();) {
            Pending shot = it.next();
            var observed = mc.level.getBlockState(shot.destination);
            boolean replaceable = observed.canBeReplaced();
            boolean matchesHeld = (shot.mainBlock != null && observed.is(shot.mainBlock))
                    || (shot.offBlock != null && observed.is(shot.offBlock));
            var verdict = shot.evidence.observe(replaceable, matchesHeld);
            if (verdict == PlacementEvidence.Verdict.MATCH) {
                it.remove();
                success(shot);
            } else if (verdict == PlacementEvidence.Verdict.OTHER_BLOCK) {
                it.remove();
                differentBlock(shot);
            } else if (verdict == PlacementEvidence.Verdict.TIMEOUT) {
                it.remove();
                unconfirmed(shot, "Не удалось установить результат постановки");
            }
        }

        // A successful rapid bridge may fill the highlighted cell before the
        // normal two-tick scan interval elapses. Immediately select the next
        // exposed face instead of showing an empty target for ~100 ms.
        if (target != null && !mc.level.getBlockState(target.destination()).canBeReplaced()) {
            targetScanTicks = 0;
        }
        if (--targetScanTicks <= 0) {
            targetScanTicks = 2;
            target = TargetFinder.find(mc, target, cfg.guideLateral, cfg.guideHeight);
        }
        if (mc.player.onGround()) {
            lastSafeY = mc.player.getY();
            fallReported = false;
        } else if (!Double.isNaN(lastSafeY) && mc.player.getY() < lastSafeY - 1.2 && !fallReported) {
            falls++;
            discardPending();
            streakEpochStartSerial = attemptHistory.latestSerial();
            streak = 0;
            setFeedback("Падение: потерял опору", 0xFFFF8888);
            fallReported = true;
        }
    }

    /** World changes are observed before BOTH the first click and the first tick.
     * Otherwise an immediate click after F8 could be cancelled by the next tick. */
    private void ensureWorld(Minecraft mc) {
        if (currentWorld == mc.level) return;
        discardPending();
        currentWorld = mc.level;
        target = null;
        targetScanTicks = 0;
        lastSafeY = Double.NaN;
        fallReported = false;
        streakEpochStartSerial = attemptHistory.latestSerial();
        streak = 0;
    }

    public void metronomeFrame(Minecraft mc, long now) {
        if (!active || !cfg.metronome || mc.player == null || mc.level == null
                || mc.gui.screen() != null) return;
        if (renderRecovery.observeFrame(now)) {
            // Do not emit a stale beat on the first frame after Alt-Tab or a
            // multi-hundred-ms freeze. Schedule a fresh slot-0 downbeat and
            // keep the grading and audible clock anchored to the same origin.
            beatOriginNs = MetronomeRecovery.originForNextDownbeat(now, cfg.bpm,
                    cfg.subdivisions, cfg.audioOffsetMs);
            pulseDelivery.prime(-1L); // slots < 0 are silent; 0 will be next
            // Old absolute slot indices and mouse intervals no longer belong
            // to the new clock. Preserve aggregate rhythm scores, but split
            // the current click burst so no phantom extra clicks are counted.
            beatConsistency.startNewBurst();
            cadence.clear();
            tempoMatcher.clear();
            clickTimes.clear();
            metronomeResyncs++;
            return;
        }
        long index = MetronomeTimeline.slotIndex(now, beatOriginNs,
                cfg.bpm, cfg.subdivisions, cfg.audioOffsetMs);
        // A positive sound offset begins in the future; negative slots must be
        // silent rather than playing a premature pulse on the first HUD frame.
        if (index < 0) return;
        // For a negative offset the first pulse was scheduled before F8.
        // Arm the current slot without emitting a fake mid-slot downbeat.
        if (cfg.audioOffsetMs < 0 && pulseDelivery.isUninitialized()) {
            pulseDelivery.prime(index);
            return;
        }
        if (pulseDelivery.advance(index) && cfg.metronomeSound) {
            // Local UI sound. Does not send a packet to servers.
            var sound = switch (cfg.soundStyle) {
                case 1 -> SoundEvents.NOTE_BLOCK_BASEDRUM.value();
                case 2 -> SoundEvents.NOTE_BLOCK_BELL.value();
                default -> SoundEvents.NOTE_BLOCK_HAT.value();
            };
            mc.getSoundManager().play(SimpleSoundInstance.forUI(sound,
                    MetronomeTimeline.accentedBeat(index, cfg.subdivisions) ? 1.30F :
                            MetronomeTimeline.downbeat(index, cfg.subdivisions) ? 1.06F : 0.90F,
                    MetronomeTimeline.downbeat(index, cfg.subdivisions) ? 0.32F : 0.20F));
        }
    }

    public BeatConsistency.Snapshot rhythmQuality() {
        return beatConsistency.snapshot();
    }

    public int recentCps(long now) {
        pruneOldClicks(now);
        return clickTimes.size();
    }

    public CadenceTracker.Snapshot recentCadence(long now) {
        return cadence.recent(now, 16);
    }

    public AttemptHistory.Recent recentStats() {
        return attemptHistory.recent(24, cfg.timingToleranceMs, cfg.aimTolerance);
    }

    public String coachingTip() {
        return TrainingAdvisor.recommend(recentStats(), cfg.bpm, cfg.timingToleranceMs, cfg.subdivisions);
    }

    public double meanAbsBeatErrorMs() {
        if (recentTimingErrors.isEmpty()) return 0;
        long sum = 0;
        for (int ms : recentTimingErrors) sum += ms;
        return sum / (double) recentTimingErrors.size();
    }

    public double angleError(Minecraft mc) {
        return mc.player == null ? 0 : AngleMath.diagonalDeviation(mc.player.getYRot());
    }

    private void discardPending() {
        for (Pending shot : pending) {
            aimHistory.cancel(shot.sample);
            attemptHistory.resolve(shot.log, AttemptHistory.Outcome.CANCELED, -1);
        }
        pending.clear();
    }

    public int feedbackAgeMs(long now) {
        return (int) ((now - lastFeedbackNs) / 1_000_000L);
    }

    public boolean diagonalKeys(Minecraft mc) {
        return mc.options.keyDown.isDown()
                && (mc.options.keyLeft.isDown() || mc.options.keyRight.isDown());
    }

    private void success(Pending shot) {
        aimHistory.resolve(shot.sample, true);
        if (shot.highlightedFace) aimCalibrator.record(shot.sample.u, shot.sample.v);
        attemptHistory.resolve(shot.log, AttemptHistory.Outcome.PLACED,
                (int) Math.max(0, (System.nanoTime() - shot.whenNs) / 1_000_000L));
        successfulBlocks++;
        refreshStreak();
        double aimError = shot.log.aimError();
        if (shot.evaluation.offTarget(aimError)) offTarget++;
        if (!cfg.feedback) return;
        ClickEvaluation.Issue issue = shot.evaluation.evaluate(shot.timingErrorMs, aimError);
        if (issue == ClickEvaluation.Issue.EARLY || issue == ClickEvaluation.Issue.LATE) {
            setFeedback("Блок стоит, но клик " + (issue == ClickEvaluation.Issue.LATE ? "ПОЗДНО " : "РАНО ")
                    + Math.abs(shot.timingErrorMs) + " мс", 0xFFFFCF77);
        } else if (issue == ClickEvaluation.Issue.AIM) {
            setFeedback(aimCorrection(shot, aimError), 0xFFFFCF77);
        } else if (cfg.angleHint && shot.angleErrorAtClick > 9.0) {
            setFeedback(String.format(java.util.Locale.ROOT,
                    "Блок стоит! Повернись ближе к 45° (ошибка %.1f°)", shot.angleErrorAtClick), 0xFFFFCF77);
        } else if (cfg.diagonalHint && !shot.diagonalAtClick) {
            setFeedback("Блок стоит! Попробуй движение S+A или S+D", 0xFFFFCF77);
        } else {
            setFeedback("ТОЧНО! Удерживай этот ритм", 0xFF82FFC5);
        }
    }

    private String aimCorrection(Pending shot, double distance) {
        Vec3 deviation = shot.hit.subtract(GuideTarget.guidePoint(shot.anchor, shot.face,
                shot.evaluation.guideLateral(), shot.evaluation.guideHeight()));
        double vertical = deviation.y;
        double alongFace = shot.face.getStepX() != 0 ? deviation.z : deviation.x;
        if (Math.abs(vertical) >= Math.abs(alongFace)) {
            return String.format(java.util.Locale.ROOT, "Поставил! Прицелься %s на %.2f блока",
                    vertical < 0 ? "ВЫШЕ" : "НИЖЕ", Math.abs(vertical));
        }
        Vec3 cameraRight = shot.lookAtClick.cross(new Vec3(0, 1, 0)).normalize();
        boolean hitToRight = deviation.dot(cameraRight) > 0;
        return String.format(java.util.Locale.ROOT, "Поставил! Прицелься %s на %.2f блока",
                hitToRight ? "ЛЕВЕЕ" : "ПРАВЕЕ", Math.abs(alongFace));
    }

    /** A different block appeared at the destination: cannot attribute it to this click. */
    private void differentBlock(Pending shot) {
        aimHistory.cancel(shot.sample);
        attemptHistory.resolve(shot.log, AttemptHistory.Outcome.OTHER_BLOCK, -1);
        unconfirmedClicks++;
        refreshStreak();
        if (cfg.feedback) setFeedback("В целевой клетке другой блок — результат неясен", 0xFFFFD36C);
    }

    /** A missing world update is inconclusive, not a confirmed misclick. */
    private void unconfirmed(Pending shot, String explanation) {
        aimHistory.cancel(shot.sample);
        attemptHistory.resolve(shot.log, AttemptHistory.Outcome.TIMEOUT, -1);
        unconfirmedClicks++;
        refreshStreak();
        if (cfg.feedback) setFeedback(explanation, 0xFFFFD36C);
    }

    private void fail(AttemptHistory.Entry entry, AttemptHistory.Outcome category, String explanation) {
        attemptHistory.resolve(entry, category, -1);
        failedClicks++;
        refreshStreak();
        if (cfg.feedback) setFeedback(explanation, 0xFFFF9797);
    }

    private void refreshStreak() {
        PlacementStreaks.Snapshot sequence = PlacementStreaks.evaluate(
                attemptHistory.snapshot(), streakEpochStartSerial);
        streak = sequence.current();
        bestStreak = Math.max(bestStreak, sequence.longest());
    }

    private void setFeedback(String text, int color) {
        feedback = text;
        feedbackColor = color;
        lastFeedbackNs = System.nanoTime();
    }

    private void pruneOldClicks(long now) {
        long threshold = now - 1_000_000_000L;
        while (!clickTimes.isEmpty() && clickTimes.peekFirst() < threshold) clickTimes.removeFirst();
    }

    private static final class Pending {
        final BlockPos anchor;
        final Direction face;
        final BlockPos destination;
        final Vec3 hit;
        final AimHistory.Sample sample;
        final AttemptHistory.Entry log;
        final long whenNs;
        final int timingErrorMs;
        final double angleErrorAtClick;
        final boolean diagonalAtClick;
        final Vec3 lookAtClick;
        final Block mainBlock;
        final Block offBlock;
        final boolean highlightedFace;
        final ClickEvaluation evaluation;
        final PlacementEvidence evidence = new PlacementEvidence(PLACEMENT_TIMEOUT_TICKS, STABLE_PLACEMENT_TICKS);

        Pending(BlockPos anchor, Direction face, BlockPos destination, Vec3 hit,
                AimHistory.Sample sample, AttemptHistory.Entry log, long whenNs, int timingErrorMs,
                double angleErrorAtClick, boolean diagonalAtClick, Vec3 lookAtClick,
                Block mainBlock, Block offBlock, boolean highlightedFace, ClickEvaluation evaluation) {
            this.anchor = anchor;
            this.face = face;
            this.destination = destination;
            this.hit = hit;
            this.sample = sample;
            this.log = log;
            this.whenNs = whenNs;
            this.timingErrorMs = timingErrorMs;
            this.angleErrorAtClick = angleErrorAtClick;
            this.diagonalAtClick = diagonalAtClick;
            this.lookAtClick = lookAtClick;
            this.mainBlock = mainBlock;
            this.offBlock = offBlock;
            this.highlightedFace = highlightedFace;
            this.evaluation = evaluation;
        }
    }
}
