package dev.dalmacc.godbridge;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.List;

/** Client-only evidence of actual right-click attempts; never infers a click from an invented input. */
public final class AttemptHistory {
    public enum Outcome {
        PENDING, PLACED, NO_BLOCKS, MISS, WRONG_FACE, OCCUPIED, DUPLICATE, OVERLAP, OTHER_BLOCK, TIMEOUT, CANCELED
    }

    public static final int CAPACITY = 8192;
    private final ArrayDeque<Entry> entries = new ArrayDeque<>();
    private long firstTimeNs = Long.MIN_VALUE;
    private int serial;

    public static final class Entry {
        public final int serial;
        public final long whenNs;
        public final int bpm;
        public final int subdivisions;
        public final int timingErrorMs;
        /** Immutable offsets in milliseconds at the physical press. */
        public final int clickOffsetMs;
        public final int audioOffsetMs;
        public final boolean timingEnabled;
        public final boolean diagonal;
        public final double angleErrorDeg;
        private Outcome outcome = Outcome.PENDING;
        private double u = Double.NaN;
        private double v = Double.NaN;
        private double aimError = Double.NaN;
        private int confirmationMs = -1;
        /** Training thresholds captured at the click, immune to later settings edits. */
        private int rhythmToleranceMs = -1;
        private double aimToleranceBlocks = Double.NaN;

        private Entry(int serial, long whenNs, int bpm, int subdivisions, int timingErrorMs,
                      int clickOffsetMs, int audioOffsetMs, boolean timingEnabled,
                      boolean diagonal, double angleErrorDeg) {
            this.serial = serial;
            this.whenNs = whenNs;
            this.bpm = bpm;
            this.subdivisions = subdivisions;
            this.timingErrorMs = timingErrorMs;
            this.clickOffsetMs = clickOffsetMs;
            this.audioOffsetMs = audioOffsetMs;
            this.timingEnabled = timingEnabled;
            this.diagonal = diagonal;
            this.angleErrorDeg = angleErrorDeg;
        }

        public Outcome outcome() { return outcome; }
        public double u() { return u; }
        public double v() { return v; }
        public double aimError() { return aimError; }
        public int confirmationMs() { return confirmationMs; }
        public int rhythmToleranceMs() { return rhythmToleranceMs; }
        public double aimToleranceBlocks() { return aimToleranceBlocks; }
        public boolean isResolved() {
            return outcome != Outcome.PENDING && outcome != Outcome.CANCELED
                    && outcome != Outcome.TIMEOUT && outcome != Outcome.OVERLAP
                    && outcome != Outcome.OTHER_BLOCK;
        }
    }

    public Entry begin(long whenNs, int bpm, int errorMs, boolean timingEnabled,
                       boolean diagonal, double angleDeg) {
        return begin(whenNs, bpm, 1, errorMs, timingEnabled, diagonal, angleDeg);
    }

    public Entry begin(long whenNs, int bpm, int subdivisions, int errorMs, boolean timingEnabled,
                       boolean diagonal, double angleDeg) {
        return begin(whenNs, bpm, subdivisions, errorMs, timingEnabled, diagonal, angleDeg, 0, 0);
    }

    /** Capture both offsets even though only clickOffset changes the error score. */
    public Entry begin(long whenNs, int bpm, int subdivisions, int errorMs, boolean timingEnabled,
                       boolean diagonal, double angleDeg, int clickOffsetMs, int audioOffsetMs) {
        RhythmMath.clickPeriodNs(bpm, subdivisions);
        if (firstTimeNs == Long.MIN_VALUE) firstTimeNs = whenNs;
        Entry entry = new Entry(++serial, whenNs, bpm, subdivisions, errorMs,
                clickOffsetMs, audioOffsetMs, timingEnabled, diagonal, angleDeg);
        if (entries.size() >= CAPACITY) entries.removeFirst();
        entries.addLast(entry);
        return entry;
    }

    /** Store the standards that were in effect when the button was pressed. */
    public void recordCriteria(Entry entry, int rhythmToleranceMs, double aimToleranceBlocks) {
        if (entry.outcome != Outcome.PENDING) return;
        if (rhythmToleranceMs < 1 || !Double.isFinite(aimToleranceBlocks) || aimToleranceBlocks <= 0)
            throw new IllegalArgumentException("Invalid accuracy criteria");
        entry.rhythmToleranceMs = rhythmToleranceMs;
        entry.aimToleranceBlocks = aimToleranceBlocks;
    }

    public void recordAim(Entry entry, double u, double v, double distance) {
        if (entry.outcome != Outcome.PENDING) return;
        entry.u = Math.clamp(u, 0, 1);
        entry.v = Math.clamp(v, 0, 1);
        entry.aimError = distance;
    }

    public void resolve(Entry entry, Outcome outcome, int confirmationMs) {
        if (outcome == Outcome.PENDING) throw new IllegalArgumentException("Use begin() for pending attempts");
        if (entry.outcome != Outcome.PENDING) return; // Cannot count an attempt twice.
        entry.outcome = outcome;
        entry.confirmationMs = confirmationMs;
    }

    public List<Entry> snapshot() { return List.copyOf(entries); }
    public int latestSerial() { return serial; }
    public long offsetMs(Entry entry) {
        return firstTimeNs == Long.MIN_VALUE ? 0 : Math.max(0, (entry.whenNs - firstTimeNs) / 1_000_000);
    }

    public Recent recent(int sampleLimit, int timingToleranceMs, double aimTolerance) {
        if (sampleLimit < 1) throw new IllegalArgumentException("sampleLimit must be positive");
        int attempts = 0, placed = 0, timely = 0, timed = 0, aimed = 0, accurate = 0;
        int rhythmSum = 0, signedSum = 0;
        double aimSum = 0;
        int[] errors = new int[Outcome.values().length];
        // Only inspect the small recent window, without copying the entire session every frame.
        Iterator<Entry> reverse = entries.descendingIterator();
        int scanned = 0;
        // A long run of pending/unconfirmed attempts must never force the HUD
        // to scan thousands of entries on every rendered frame.
        int scanBudget = Math.max(96, sampleLimit * 4);
        while (reverse.hasNext() && attempts < sampleLimit && scanned++ < scanBudget) {
            Entry e = reverse.next();
            if (!e.isResolved()) continue;
            attempts++;
            if (e.outcome == Outcome.PLACED) placed++;
            else errors[e.outcome.ordinal()]++;
            if (e.timingEnabled) {
                timed++;
                rhythmSum += Math.abs(e.timingErrorMs);
                signedSum += e.timingErrorMs;
                int rhythmWindow = e.rhythmToleranceMs > 0 ? e.rhythmToleranceMs : timingToleranceMs;
                if (Math.abs(e.timingErrorMs) <= RhythmMath.effectiveToleranceMs(e.bpm, rhythmWindow, e.subdivisions)) timely++;
            }
            if (Double.isFinite(e.aimError)) {
                aimed++;
                aimSum += e.aimError;
                if (e.aimError <= (Double.isFinite(e.aimToleranceBlocks) ? e.aimToleranceBlocks : aimTolerance))
                    accurate++;
            }
        }
        Outcome mostCommonError = null;
        int largest = 0;
        for (Outcome outcome : Outcome.values()) {
            if (errors[outcome.ordinal()] > largest) {
                mostCommonError = outcome;
                largest = errors[outcome.ordinal()];
            }
        }
        return new Recent(attempts, placed, timed, timely, aimed, accurate,
                timed == 0 ? 0 : rhythmSum / (double) timed,
                timed == 0 ? 0 : signedSum / (double) timed,
                aimed == 0 ? 0 : aimSum / aimed, mostCommonError);
    }

    public record Recent(int attempts, int placed, int timed, int timely, int aimed, int accurate,
                         double meanAbsRhythmMs, double meanSignedRhythmMs, double meanAimError,
                         Outcome mainFailure) {
        public int successPercent() { return attempts == 0 ? 0 : (int) Math.round(100.0 * placed / attempts); }
        public int rhythmPercent() { return timed == 0 ? 0 : (int) Math.round(100.0 * timely / timed); }
        public int aimPercent() { return aimed == 0 ? 0 : (int) Math.round(100.0 * accurate / aimed); }
    }

    public void clear() {
        entries.clear();
        firstTimeNs = Long.MIN_VALUE;
        serial = 0;
    }
}
