package dev.dalmacc.godbridge;

/**
 * One clock for pulse scheduling and the quarter-note HUD ruler.
 *
 * Sound and evaluation intentionally have INDEPENDENT offsets:
 * soundOffsetMs moves audible pulses; clickOffsetMs is latency calibration for
 * scoring an actual physical click. At zero offsets both use the same grid.
 * All calculations use integer nanoseconds to avoid drifting quarter notes.
 */
public final class MetronomeTimeline {
    private MetronomeTimeline() {}

    public static long slotIndex(long nowNs, long originNs, int bpm,
                                 int subdivisions, int offsetMs) {
        long period = RhythmMath.clickPeriodNs(bpm, subdivisions);
        return Math.floorDiv(nowNs - originNs - offsetMs * 1_000_000L, period);
    }

    public static double quarterPhase(long nowNs, long originNs, int bpm,
                                      int subdivisions, int offsetMs) {
        long quarter = Math.multiplyExact(RhythmMath.clickPeriodNs(bpm, subdivisions), subdivisions);
        return Math.floorMod(nowNs - originNs - offsetMs * 1_000_000L, quarter) / (double) quarter;
    }

    public static boolean downbeat(long slot, int subdivisions) {
        if (subdivisions < 1 || subdivisions > 4) throw new IllegalArgumentException("subdivisions must be 1..4");
        return Math.floorMod(slot, subdivisions) == 0;
    }

    public static boolean accentedBeat(long slot, int subdivisions) {
        if (subdivisions < 1 || subdivisions > 4) throw new IllegalArgumentException("subdivisions must be 1..4");
        return Math.floorMod(slot, 4L * subdivisions) == 0;
    }
}
