package dev.dalmacc.godbridge;

/** Diagonal backward bridging orientation relative to the cardinal world axes. */
public final class AngleMath {
    private AngleMath() {}

    /** Absolute yaw deviation from a diagonal (45, 135, -45 or -135 degrees). */
    public static double diagonalDeviation(double yawDegrees) {
        return Math.abs(Math.IEEEremainder(yawDegrees - 45.0, 90.0));
    }
}
