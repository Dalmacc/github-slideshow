package dev.dalmacc.godbridge;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Four focused pages: basic controls, click timing, aim, and recorded attempts. */
public final class TrainerScreen extends Screen {
    private final Screen previous;
    private final TrainerConfig config;
    private final BridgeCoach coach;
    private int page;
    private String exportStatus = "";

    public TrainerScreen(Screen previous, TrainerConfig config, BridgeCoach coach) {
        super(Component.literal("God Bridge Trainer • Настройки"));
        this.previous = previous;
        this.config = config;
        this.coach = coach;
    }

    @Override
    protected void init() {
        super.init();
        int center = width / 2;
        int top = Math.max(5, (height - 224) / 2);
        if (page == 0) {
            button(center - 154, top + 29, 46, "−20", b -> bpm(-20));
            button(center - 103, top + 29, 45, "−1", b -> bpm(-1));
            button(center + 58, top + 29, 45, "+1", b -> bpm(1));
            button(center + 108, top + 29, 46, "+20", b -> bpm(20));
            toggle(center - 154, top + 59, 151, "HUD", () -> config.hud, v -> config.hud = v);
            toggle(center + 3, top + 59, 151, "Мишень", () -> config.targetMarker, v -> config.targetMarker = v);
            toggle(center - 154, top + 83, 151, "Метроном", () -> config.metronome, v -> config.metronome = v);
            toggle(center + 3, top + 83, 151, "Звук", () -> config.metronomeSound, v -> config.metronomeSound = v);
            toggle(center - 154, top + 107, 151, "Ошибки", () -> config.feedback, v -> config.feedback = v);
            toggle(center + 3, top + 107, 151, "S+A / S+D", () -> config.diagonalHint, v -> config.diagonalHint = v);
            toggle(center - 154, top + 131, 151, "Теплокарта", () -> config.heatmap, v -> config.heatmap = v);
            toggle(center + 3, top + 131, 151, "Угол 45°", () -> config.angleHint, v -> config.angleHint = v);
        } else if (page == 1) {
            for (int i = 1; i <= 4; i++) {
                int value = i;
                button(center - 154 + (i - 1) * 78, top + 29, 73,
                        (i == config.subdivisions ? "✓ " : "") + "×" + i,
                        b -> { config.subdivisions = value; rebuildWidgets(); });
            }
            // Two distinct controls: the first calibrates *click scoring* against
            // hardware audio latency, while the second actually moves the pulse.
            button(center - 154, top + 60, 47, "−10", b -> config.beatOffsetMs =
                    TrainerConfig.clamp(config.beatOffsetMs - 10, -200, 200));
            button(center + 107, top + 60, 47, "+10", b -> config.beatOffsetMs =
                    TrainerConfig.clamp(config.beatOffsetMs + 10, -200, 200));
            button(center - 154, top + 91, 47, "−10", b -> config.audioOffsetMs =
                    TrainerConfig.clamp(config.audioOffsetMs - 10, -200, 200));
            button(center + 107, top + 91, 47, "+10", b -> config.audioOffsetMs =
                    TrainerConfig.clamp(config.audioOffsetMs + 10, -200, 200));
            button(center - 154, top + 122, 47, "−5", b -> config.timingToleranceMs =
                    TrainerConfig.clamp(config.timingToleranceMs - 5, 20, 200));
            button(center + 107, top + 122, 47, "+5", b -> config.timingToleranceMs =
                    TrainerConfig.clamp(config.timingToleranceMs + 5, 20, 200));
            // Explicit tap-tempo application; never change the user's BPM without consent.
            button(center - 154, top + 149, 150, shortSoundName(), b -> {
                config.soundStyle = (config.soundStyle + 1) % 3;
                b.setMessage(Component.literal(shortSoundName()));
            });
            button(center + 3, top + 149, 151, "BPM по ПКМ", b -> {
                TempoMatcher.Estimate estimate = coach.tempoMatcher.estimate(config.subdivisions);
                if (estimate.ready()) {
                    config.bpm = estimate.suggestedBpm();
                    b.setMessage(Component.literal("BPM: " + config.bpm + " ✓"));
                } else {
                    b.setMessage(Component.literal(switch (estimate.reason()) {
                        case TOO_FEW -> "Ещё " + estimate.pressesRemaining() + " интервалов";
                        case IRREGULAR -> "Ритм нестабилен";
                        case OUT_OF_RANGE -> "Темп вне 100–600";
                        case READY -> "BPM по ПКМ";
                    }));
                }
            });
        } else if (page == 2) {
            button(center - 154, top + 29, 47, "−.02", b -> config.guideHeight =
                    Math.clamp(Math.round((config.guideHeight - 0.02) * 100.0) / 100.0, 0.70, 0.99));
            button(center + 107, top + 29, 47, "+.02", b -> config.guideHeight =
                    Math.clamp(Math.round((config.guideHeight + 0.02) * 100.0) / 100.0, 0.70, 0.99));
            button(center - 154, top + 65, 47, "−.05", b -> config.guideLateral =
                    Math.clamp(Math.round((config.guideLateral - 0.05) * 100.0) / 100.0, 0.10, 0.90));
            button(center + 107, top + 65, 47, "+.05", b -> config.guideLateral =
                    Math.clamp(Math.round((config.guideLateral + 0.05) * 100.0) / 100.0, 0.10, 0.90));
            button(center - 154, top + 101, 47, "−.02", b -> config.aimTolerance =
                    Math.max(0.05, Math.round((config.aimTolerance - 0.02) * 100.0) / 100.0));
            button(center + 107, top + 101, 47, "+.02", b -> config.aimTolerance =
                    Math.min(0.45, Math.round((config.aimTolerance + 0.02) * 100.0) / 100.0));
            AimCalibrator.Estimate estimate = coach.aimCalibrator.estimate();
            if (estimate.reliable()) {
                button(center - 154, top + 136, 308, "Применить мою точку удачных кликов", b -> {
                    config.guideLateral = Math.round(estimate.u() * 100.0) / 100.0;
                    config.guideHeight = Math.round(estimate.v() * 100.0) / 100.0;
                    coach.target = null;
                });
            }
        } else {
            button(center - 154, top + 110, 308, "Экспорт CSV в config/godbridge_trainer/reports", b -> {
                try {
                    Path saved = SessionExporter.export(coach.attemptHistory,
                            FabricLoader.getInstance().getConfigDir().resolve("godbridge_trainer/reports"));
                    exportStatus = "Сохранено: " + saved.getFileName();
                } catch (IOException ex) {
                    exportStatus = "Ошибка экспорта: проверь права на config/";
                }
            });
        }

        button(center - 154, top + 172, 150, page == 0 ? "Сбросить статистику" : "← Назад", b -> {
            if (page == 0) coach.reset();
            else switchPage(page - 1);
        });
        button(center + 4, top + 172, 150, page == 3 ? "Готово" : "Далее →", b -> {
            if (page == 3) onClose();
            else switchPage(page + 1);
        });
    }

    private void bpm(int change) {
        config.bpm = TrainerConfig.clamp(config.bpm + change, 100, 600);
    }

    private String shortSoundName() {
        return "Звук: " + switch (config.soundStyle) {
            case 1 -> "барабан";
            case 2 -> "колокольчик";
            default -> "хай-хэт";
        };
    }

    private void switchPage(int newPage) {
        page = newPage;
        rebuildWidgets();
    }

    private void button(int x, int y, int w, String label, Consumer<Button> click) {
        this.addRenderableWidget(Button.builder(Component.literal(label), btn -> {
            int previousBpm = config.bpm;
            int previousSubdivisions = config.subdivisions;
            click.accept(btn);
            if (config.bpm != previousBpm || config.subdivisions != previousSubdivisions) coach.resyncBeat();
            config.save();
        }).bounds(x, y, w, 20).build());
    }

    private void toggle(int x, int y, int w, String name, BooleanSupplier current, Consumer<Boolean> setter) {
        this.addRenderableWidget(Button.builder(Component.literal(option(name, current.getAsBoolean())), btn -> {
            setter.accept(!current.getAsBoolean());
            btn.setMessage(Component.literal(option(name, current.getAsBoolean())));
            config.save();
        }).bounds(x, y, w, 20).build());
    }

    private static String option(String name, boolean enabled) {
        return name + ": " + (enabled ? "ВКЛ" : "ВЫКЛ");
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int center = width / 2;
        int top = Math.max(5, (height - 224) / 2);
        graphics.centeredText(font, title, center, top + 3, 0xFFEAF1FC);
        if (page == 0) {
            graphics.centeredText(font, config.bpm + " BPM", center, top + 34, 0xFF85F3C2);
            graphics.centeredText(font, String.format(Locale.ROOT, "×%d = %.1f CPS",
                    config.subdivisions, RhythmMath.targetCps(config.bpm, config.subdivisions)),
                    center, top + 49, 0xFFAFBBD5);
        } else if (page == 1) {
            graphics.centeredText(font, "Кликов на удар: " + config.subdivisions, center, top + 14, 0xFF85F3C2);
            graphics.centeredText(font, "Оценка клика: " + config.beatOffsetMs + " мс",
                    center, top + 65, 0xFF85F3C2);
            graphics.centeredText(font, "Звук: " + config.audioOffsetMs + " мс",
                    center, top + 96, 0xFF85F3C2);
            graphics.centeredText(font, "Допуск: ±" + RhythmMath.effectiveToleranceMs(config.bpm,
                    config.timingToleranceMs, config.subdivisions) + " мс",
                    center, top + 127, 0xFF85F3C2);
            TempoMatcher.Estimate pace = coach.tempoMatcher.estimate(config.subdivisions);
            if (pace.ready()) graphics.centeredText(font, String.format(Locale.ROOT,
                    "По кликам: %.1f CPS → %d BPM", pace.cps(), pace.suggestedBpm()),
                    center, top + 139, 0xFFAFBBD5);
        } else if (page == 2) {
            graphics.centeredText(font, String.format(Locale.ROOT, "Высота: %.2f блока",
                    config.guideHeight), center, top + 34, 0xFF85F3C2);
            graphics.centeredText(font, String.format(Locale.ROOT, "По горизонтали: %.2f",
                    config.guideLateral), center, top + 70, 0xFF85F3C2);
            graphics.centeredText(font, String.format(Locale.ROOT, "Допуск по прицелу: %.2f",
                    config.aimTolerance), center, top + 106, 0xFF85F3C2);
            AimCalibrator.Estimate estimate = coach.aimCalibrator.estimate();
            if (estimate.reliable()) {
                graphics.centeredText(font, String.format(Locale.ROOT,
                        "Твоя точка: %.2f / %.2f, доверие %d%%",
                        estimate.u(), estimate.v(), estimate.confidencePercent()),
                        center, top + 157, 0xFF85F3C2);
            } else {
                graphics.centeredText(font, "Калибровка: " + estimate.samples()
                        + " успешных кликов, нужна стабильная группа от 12",
                        center, top + 149, 0xFFAFBBD5);
            }
        } else {
            AttemptHistory.Recent r = coach.recentStats();
            graphics.centeredText(font, "Подтверждено: " + r.attempts() + " (последние 24)",
                    center, top + 27, 0xFFDDE5F7);
            graphics.centeredText(font, "Постановки: " + r.successPercent() + "% · Ритм: " + r.rhythmPercent() + "%",
                    center, top + 46, 0xFF85F3C2);
            graphics.centeredText(font, "Попадания: " + r.aimPercent() + "% · Всего блоков: " + coach.successfulBlocks,
                    center, top + 65, 0xFFDDE5F7);
            graphics.centeredText(font, "Неясные постановки: " + coach.unconfirmedClicks
                    + " · Перекр. кликов: " + coach.duplicateClicks,
                    center, top + 86, 0xFFFFD36C);
            BeatConsistency.Snapshot rhythm = coach.rhythmQuality();
            graphics.centeredText(font, "Доли: " + rhythm.hitPercent() + "% · Пропуски: "
                    + rhythm.missedBeats() + " · Лишние: " + rhythm.extraClicks(),
                    center, top + 98, 0xFFAFBBD5);
            if (!exportStatus.isEmpty()) graphics.centeredText(font, exportStatus,
                    center, top + 146, 0xFF85F3C2);
        }
        graphics.centeredText(font, "F8 — старт  •  F9 — меню  •  F10 — сброс",
                center, top + 198, 0xFFB0BDD2);
    }

    @Override
    public void onClose() {
        config.save();
        // Do not penalize the first click after spending time in settings.
        if (coach.active) coach.resyncBeat();
        if (this.minecraft != null) this.minecraft.gui.setScreen(previous);
    }
}
