package dev.dalmacc.godbridge;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Selects a target only when its face is exposed and a normal ray can really hit it. */
public final class TargetFinder {
    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private TargetFinder() {}

    /** Recheck a cached marker just before rendering: the destination may have been filled
     * or an intervening block may have occluded it since the last target scan. */
    public static boolean stillVisible(Minecraft mc, GuideTarget target) {
        if (target == null || mc.level == null || mc.player == null) return false;
        if (!mc.level.getBlockState(target.anchor()).isCollisionShapeFullBlock(mc.level, target.anchor()))
            return false;
        if (!mc.level.getBlockState(target.destination()).canBeReplaced()) return false;
        Vec3 eye = mc.player.getEyePosition();
        if (eye.distanceToSqr(target.point()) > 4.7 * 4.7) return false;
        return rayHitsFace(mc, eye, target.anchor(), target.face(), target.point());
    }

    private static boolean rayHitsFace(Minecraft mc, Vec3 eye, BlockPos anchor, Direction side, Vec3 point) {
        Vec3 rayEnd = point.subtract(side.getStepX() * 0.09, 0, side.getStepZ() * 0.09);
        BlockHitResult ray = mc.level.clip(new ClipContext(eye, rayEnd,
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, mc.player));
        return ray.getType() == HitResult.Type.BLOCK
                && ray.getBlockPos().equals(anchor) && ray.getDirection() == side;
    }

    public static GuideTarget find(Minecraft mc, GuideTarget old, double guideLateral, double guideHeight) {
        if (mc.player == null || mc.level == null) return null;

        var player = mc.player;
        var level = mc.level;
        Vec3 eye = player.getEyePosition();
        Vec3 view = player.getLookAngle().normalize();
        Vec3 velocity = player.getDeltaMovement();
        Vec3 desiredMove = new Vec3(velocity.x, 0, velocity.z);
        if (desiredMove.lengthSqr() < 0.0004) {
            // In the absence of movement, choose the direction behind the player's view.
            desiredMove = new Vec3(-view.x, 0, -view.z);
        }
        desiredMove = desiredMove.normalize();

        BlockPos feetSupport = BlockPos.containing(player.getX(), player.getY() - 0.22, player.getZ());
        GuideTarget best = null;
        double bestScore = -Double.MAX_VALUE;

        // God bridging extends blocks on the same Y layer as the block under the feet.
        // Do not accidentally suggest nearby walls, slabs, fences or an upper level.
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos anchor = feetSupport.offset(dx, 0, dz);
                if (!level.getBlockState(anchor).isCollisionShapeFullBlock(level, anchor)) continue;
                for (Direction side : SIDES) {
                    BlockPos destination = anchor.relative(side);
                    if (!level.getBlockState(destination).canBeReplaced()) continue;

                    Vec3 point = GuideTarget.guidePoint(anchor, side, guideLateral, guideHeight);
                    Vec3 toPoint = point.subtract(eye);
                    double distance = toPoint.length();
                    if (distance < 0.25 || distance > 4.7) continue;
                    double viewDot = view.dot(toPoint.scale(1.0 / distance));
                    if (viewDot < 0.20) continue;

                    // Cast THROUGH the visible side face into the block. An outward offset
                    // would stop before the surface, making every target invisible.
                    if (!rayHitsFace(mc, eye, anchor, side, point)) continue;

                    Vec3 normal = new Vec3(side.getStepX(), 0, side.getStepZ());
                    double preferredDirection = normal.dot(desiredMove);
                    double score = viewDot * 9.0 + preferredDirection * 1.8 - distance * 0.14;
                    // Prevent markers jumping between multiple nearly equivalent blocks.
                    if (old != null && old.anchor().equals(anchor) && old.face() == side) score += 0.50;
                    if (score > bestScore) {
                        bestScore = score;
                        best = new GuideTarget(anchor, side, point);
                    }
                }
            }
        }
        return best;
    }
}
