package dev.dalmacc.godbridge;

/** Actionable coaching from a window of confirmed attempts. Suggestions never control the player. */
public final class TrainingAdvisor {
    private TrainingAdvisor() {}

    public static String recommend(AttemptHistory.Recent r, int bpm, int toleranceMs) {
        return recommend(r, bpm, toleranceMs, 1);
    }

    public static String recommend(AttemptHistory.Recent r, int bpm, int toleranceMs, int subdivisions) {
        if (r.attempts() < 12) return "Ещё " + (12 - r.attempts()) + " попыток до оценки техники";
        if (r.successPercent() < 60) {
            return switch (r.mainFailure()) {
                case MISS -> "Главная ошибка: не попадаешь по блоку";
                case WRONG_FACE -> "Главная ошибка: попадаешь сверху/снизу";
                case NO_BLOCKS -> "Возьми полные блоки перед попыткой";
                case OCCUPIED -> "Целевая клетка уже занята";
                case DUPLICATE -> "Не повторяй клик в одну точку";
                case TIMEOUT -> "Блоки не появляются: проверь дистанцию и условия";
                case null, default -> "Сначала добейся стабильных постановок";
            };
        }
        if (r.aimed() >= 8 && r.aimPercent() < 70) {
            return "Точность: приблизь клики к светлой мишени";
        }
        if (r.timed() >= 8 && r.rhythmPercent() < 70) {
            int effective = RhythmMath.effectiveToleranceMs(bpm, toleranceMs, subdivisions);
            if (r.meanSignedRhythmMs() > effective / 2.0)
                return "Чаще поздно: начинай клик чуть раньше";
            if (r.meanSignedRhythmMs() < -effective / 2.0)
                return "Чаще рано: начинай клик чуть позже";
            return "Ритм плавает: выровняй интервалы ПКМ";
        }
        if (r.attempts() >= 20 && r.successPercent() >= 85 &&
                (r.timed() < 8 || r.rhythmPercent() >= 80)) {
            return "Стабильно! Попробуй поднять BPM на 10";
        }
        return "Продолжай: цель — 85% постановок и точный ритм";
    }
}
