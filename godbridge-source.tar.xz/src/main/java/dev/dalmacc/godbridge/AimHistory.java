package dev.dalmacc.godbridge;

import java.util.ArrayDeque;
import java.util.List;

/** A bounded record of clicks on block side faces, in normalized face coordinates. */
public final class AimHistory {
    public enum Outcome { PENDING, PLACED, FAILED, CANCELED }

    public static final class Sample {
        public final double u;
        public final double v;
        private Outcome outcome = Outcome.PENDING;

        private Sample(double u, double v) {
            this.u = Math.clamp(u, 0.0, 1.0);
            this.v = Math.clamp(v, 0.0, 1.0);
        }

        public Outcome outcome() {
            return outcome;
        }
    }

    public static final int MAX_SAMPLES = 48;
    private final ArrayDeque<Sample> samples = new ArrayDeque<>();

    public Sample record(double u, double v) {
        Sample sample = new Sample(u, v);
        if (samples.size() == MAX_SAMPLES) samples.removeFirst();
        samples.addLast(sample);
        return sample;
    }

    public void resolve(Sample sample, boolean wasPlaced) {
        if (sample != null && sample.outcome == Outcome.PENDING)
            sample.outcome = wasPlaced ? Outcome.PLACED : Outcome.FAILED;
    }

    public void cancel(Sample sample) {
        if (sample != null && sample.outcome == Outcome.PENDING) sample.outcome = Outcome.CANCELED;
    }

    public List<Sample> snapshot() {
        return List.copyOf(samples);
    }

    public int size() {
        return samples.size();
    }

    public void clear() {
        samples.clear();
    }
}
