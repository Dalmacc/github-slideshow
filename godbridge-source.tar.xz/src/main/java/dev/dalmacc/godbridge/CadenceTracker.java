package dev.dalmacc.godbridge;

import java.util.ArrayDeque;
import java.util.Iterator;

/** Measures real finger cadence, even when the metronome is disabled. */
public final class CadenceTracker {
    private static final int CAPACITY = 128;
    private static final long BURST_GAP_NS = 400_000_000L;
    private final ArrayDeque<Long> times = new ArrayDeque<>();

    public void record(long timeNs) {
        if (!times.isEmpty() && timeNs <= times.peekLast()) return;
        if (times.size() == CAPACITY) times.removeFirst();
        times.addLast(timeNs);
    }

    public Snapshot recent(long nowNs, int maxIntervals) {
        if (maxIntervals < 1) throw new IllegalArgumentException("maxIntervals must be positive");
        if (times.size() < 2 || nowNs - times.peekLast() > BURST_GAP_NS)
            return new Snapshot(0, 0, 0, 0);
        Iterator<Long> reverse = times.descendingIterator();
        long newer = reverse.next();
        double sum = 0, sumSquares = 0;
        int n = 0;
        while (reverse.hasNext() && n < maxIntervals) {
            long older = reverse.next();
            long delta = newer - older;
            if (delta <= 0 || delta > BURST_GAP_NS) break;
            double ms = delta / 1_000_000.0;
            sum += ms;
            sumSquares += ms * ms;
            n++;
            newer = older;
        }
        if (n == 0) return new Snapshot(0, 0, 0, 0);
        double mean = sum / n;
        double standardDeviation = Math.sqrt(Math.max(0, sumSquares / n - mean * mean));
        return new Snapshot(n, 1000.0 / mean, mean, standardDeviation);
    }

    public void clear() { times.clear(); }

    public record Snapshot(int intervals, double cps, double meanIntervalMs, double jitterMs) {
        /** Coefficient of variation gives a scale-independent measure of uneven clicking. */
        public double jitterPercent() {
            return meanIntervalMs == 0 ? 0 : 100.0 * jitterMs / meanIntervalMs;
        }
    }
}
