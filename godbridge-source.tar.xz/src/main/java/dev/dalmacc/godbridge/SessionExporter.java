package dev.dalmacc.godbridge;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Explicit local-only export; no telemetry, uploads, or third-party dependencies. */
public final class SessionExporter {
    private static final DateTimeFormatter NAME_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private SessionExporter() {}

    public static Path export(AttemptHistory history, Path directory) throws IOException {
        Files.createDirectories(directory);
        Path file = directory.resolve("godbridge-" + LocalDateTime.now().format(NAME_TIME) + ".csv");
        int suffix = 2;
        while (Files.exists(file)) {
            file = directory.resolve("godbridge-" + LocalDateTime.now().format(NAME_TIME) + "-" + suffix++ + ".csv");
        }
        StringBuilder csv = new StringBuilder("attempt,session_ms,result,bpm,subdivisions,rhythm_error_ms,aim_error_blocks,face_u,face_v,angle_error_deg,diagonal,confirm_ms,rhythm_tolerance_ms,aim_tolerance_blocks,click_offset_ms,audio_offset_ms\n");
        for (AttemptHistory.Entry e : history.snapshot()) {
            csv.append(e.serial).append(',')
                    .append(history.offsetMs(e)).append(',')
                    .append(e.outcome().name()).append(',')
                    .append(e.bpm).append(',')
                    .append(e.subdivisions).append(',')
                    .append(e.timingEnabled ? Integer.toString(e.timingErrorMs) : "").append(',')
                    .append(num(e.aimError())).append(',')
                    .append(num(e.u())).append(',')
                    .append(num(e.v())).append(',')
                    .append(num(e.angleErrorDeg)).append(',')
                    .append(e.diagonal).append(',')
                    .append(e.confirmationMs() < 0 ? "" : e.confirmationMs()).append(',')
                    .append(e.rhythmToleranceMs() < 0 ? "" : e.rhythmToleranceMs()).append(',')
                    .append(num(e.aimToleranceBlocks())).append(',')
                    .append(e.clickOffsetMs).append(',')
                    .append(e.audioOffsetMs)
                    .append('\n');
        }
        // CREATE_NEW protects earlier reports when two exports occur within one second.
        Files.writeString(file, csv.toString(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        return file;
    }

    private static String num(double n) {
        return Double.isFinite(n) ? String.format(Locale.ROOT, "%.4f", n) : "";
    }
}
