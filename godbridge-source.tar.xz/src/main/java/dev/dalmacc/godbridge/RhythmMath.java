package dev.dalmacc.godbridge;

/** Pure, deterministic beat timing independent of client FPS and tick rate. */
public final class RhythmMath {
    private RhythmMath() {}

    public static long beatPeriodNs(int bpm) {
        if (bpm <= 0) throw new IllegalArgumentException("BPM must be positive");
        return Math.round(60_000_000_000.0 / bpm);
    }

    /** One quarter-note beat is subdivided into 1..4 evenly spaced clicks. */
    public static long clickPeriodNs(int bpm, int subdivisions) {
        if (subdivisions < 1 || subdivisions > 4)
            throw new IllegalArgumentException("Subdivisions must be 1..4");
        return Math.round(beatPeriodNs(bpm) / (double) subdivisions);
    }

    public static double targetCps(int bpm, int subdivisions) {
        clickPeriodNs(bpm, subdivisions); // validate arguments
        return bpm * subdivisions / 60.0;
    }

    /** Negative = early, positive = late, relative to the nearest click subdivision. */
    public static int signedErrorMs(long pressedNs, long originNs, int bpm, int beatOffsetMs,
                                    int subdivisions) {
        long period = clickPeriodNs(bpm, subdivisions);
        long elapsed = pressedNs - originNs - beatOffsetMs * 1_000_000L;
        long remainder = Math.floorMod(elapsed + period / 2, period) - period / 2;
        return (int) Math.round(remainder / 1_000_000.0);
    }

    /** API retained for legacy 0.3 unit tests and clients. */
    public static int signedErrorMs(long pressedNs, long originNs, int bpm, int beatOffsetMs) {
        return signedErrorMs(pressedNs, originNs, bpm, beatOffsetMs, 1);
    }

    /** Acceptance window never exceeds a quarter of the *click* period. */
    public static int effectiveToleranceMs(int bpm, int requestedMs, int subdivisions) {
        return Math.max(1, Math.min(Math.max(1, requestedMs),
                (int) (clickPeriodNs(bpm, subdivisions) / 4_000_000L)));
    }

    public static int effectiveToleranceMs(int bpm, int requestedMs) {
        return effectiveToleranceMs(bpm, requestedMs, 1);
    }

    /** Phase is aligned to the *accepted click*, including a configured input offset. */
    public static double clickPhase(long nowNs, long originNs, int bpm, int offsetMs, int subdivisions) {
        long period = clickPeriodNs(bpm, subdivisions);
        return Math.floorMod(nowNs - originNs - offsetMs * 1_000_000L, period) / (double) period;
    }

    public static double beatPhase(long nowNs, long originNs, int bpm) {
        long period = beatPeriodNs(bpm);
        return Math.floorMod(nowNs - originNs, period) / (double) period;
    }
}
