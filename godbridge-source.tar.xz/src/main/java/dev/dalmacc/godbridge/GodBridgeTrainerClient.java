package dev.dalmacc.godbridge;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class GodBridgeTrainerClient implements ClientModInitializer {
    public static final String MOD_ID = "godbridge_trainer";
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "trainer"));
    private static final KeyMapping TOGGLE = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.godbridge_trainer.toggle", InputConstants.Type.KEYBOARD, InputConstants.KEY_F8, CATEGORY));
    private static final KeyMapping SETTINGS = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.godbridge_trainer.settings", InputConstants.Type.KEYBOARD, InputConstants.KEY_F9, CATEGORY));
    private static final KeyMapping RESET = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.godbridge_trainer.reset", InputConstants.Type.KEYBOARD, InputConstants.KEY_F10, CATEGORY));

    private static final BridgeCoach COACH = new BridgeCoach(TrainerConfig.load());

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (TOGGLE.consumeClick()) COACH.toggle();
            while (SETTINGS.consumeClick()) mc.gui.setScreen(new TrainerScreen(mc.gui.screen(), COACH.cfg, COACH));
            while (RESET.consumeClick()) COACH.reset();
            COACH.tick(mc);
        });
        // Called every *world render frame*, regardless of F1/HUD visibility.
        // 26.3 uses LevelRenderEvents (WorldRenderEvents was renamed).
        // Keep sound on the Minecraft render thread; do not issue sound calls
        // from an independent background timer or from a 20 TPS tick callback.
        LevelRenderEvents.END_MAIN.register(context ->
                COACH.metronomeFrame(Minecraft.getInstance(), System.nanoTime()));
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "trainer_hud"),
                (graphics, tick) -> TrainerHud.draw(graphics, Minecraft.getInstance(), COACH));
    }

    /** Invoked on the client thread by the 26.3 SDL mouse input Mixin. */
    public static void rawRightClick(long timeNs) {
        COACH.onRawRightClick(Minecraft.getInstance(), timeNs);
    }
}
