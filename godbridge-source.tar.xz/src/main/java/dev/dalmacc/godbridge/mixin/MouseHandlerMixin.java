package dev.dalmacc.godbridge.mixin;

import com.mojang.blaze3d.platform.InputConstants;
import dev.dalmacc.godbridge.GodBridgeTrainerClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** SDL 3: right mouse button is 3, NOT GLFW's old 1. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V", at = @At("HEAD"))
    private void godbridge$rightClick(long windowHandle, MouseButtonInfo mouse, int action, CallbackInfo ci) {
        if (action != InputConstants.PRESS || mouse.button() != InputConstants.MOUSE_BUTTON_RIGHT) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gui.screen() != null) return;
        long timestamp = System.nanoTime();
        // The handler is normally on the client thread; schedule defensively without blocking input.
        if (mc.isSameThread()) GodBridgeTrainerClient.rawRightClick(timestamp);
        else mc.execute(() -> GodBridgeTrainerClient.rawRightClick(timestamp));
    }
}
