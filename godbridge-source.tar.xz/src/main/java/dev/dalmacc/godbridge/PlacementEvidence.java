package dev.dalmacc.godbridge;

/**
 * Evidence gate for client-observed placements. One game tick of a changed
 * block is insufficient: predictions and very short world transitions can
 * otherwise produce false success. Pure Java to permit offline tests.
 *
 * This is NOT server-side authorship proof. A second player placing an
 * identical block is indistinguishable without a server-side protocol.
 */
public final class PlacementEvidence {
    public enum Verdict { WAITING, MATCH, OTHER_BLOCK, TIMEOUT }

    private final int timeoutTicks;
    private final int stableTicksRequired;
    private int elapsedTicks;
    private int matchTicks;
    private int otherTicks;
    private Verdict finalVerdict = Verdict.WAITING;

    public PlacementEvidence(int timeoutTicks, int stableTicksRequired) {
        if (timeoutTicks < 1 || stableTicksRequired < 1 || stableTicksRequired > timeoutTicks)
            throw new IllegalArgumentException("Invalid placement evidence thresholds");
        this.timeoutTicks = timeoutTicks;
        this.stableTicksRequired = stableTicksRequired;
    }

    /**
     * Call exactly once per client tick.
     * @param replaceable whether target cell is currently replaceable
     * @param matchingBlock true only if the observed state matches an item
     *                      held in a hand at the time of the click
     */
    public Verdict observe(boolean replaceable, boolean matchingBlock) {
        if (finalVerdict != Verdict.WAITING) return finalVerdict;
        elapsedTicks++;
        if (replaceable) {
            matchTicks = otherTicks = 0;
        } else if (matchingBlock) {
            matchTicks++;
            otherTicks = 0;
            if (matchTicks >= stableTicksRequired) return finalVerdict = Verdict.MATCH;
        } else {
            otherTicks++;
            matchTicks = 0;
            if (otherTicks >= stableTicksRequired) return finalVerdict = Verdict.OTHER_BLOCK;
        }
        if (elapsedTicks >= timeoutTicks) return finalVerdict = Verdict.TIMEOUT;
        return Verdict.WAITING;
    }

    public int elapsedTicks() { return elapsedTicks; }
}
