package dev.dalmacc.godbridge;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * Finds a reproducible click tempo from a physical right-click burst.
 * This class NEVER changes settings: the player must apply its recommendation
 * explicitly in the Rhythm menu. Pure Java, independent from render FPS.
 */
public final class TempoMatcher {
    private static final int MAX_INTERVALS = 48;
    private static final int MIN_INLIERS = 6;
    private static final long BURST_GAP_NS = 700_000_000L;
    private static final long MIN_CLICK_GAP_NS = 28_000_000L;
    private final ArrayDeque<Long> intervals = new ArrayDeque<>();
    private long previousNs = Long.MIN_VALUE;

    public void record(long clickNs) {
        if (previousNs != Long.MIN_VALUE) {
            long delta = clickNs - previousNs;
            if (delta <= 0) return;
            // An OS bounce / accidental near-simultaneous mouse event must not
            // alter the last valid press or fake a faster rhythm.
            if (delta < MIN_CLICK_GAP_NS) return;
            if (delta > BURST_GAP_NS) {
                intervals.clear();
            } else {
                if (intervals.size() == MAX_INTERVALS) intervals.removeFirst();
                intervals.addLast(delta);
            }
        }
        previousNs = clickNs;
    }

    public Estimate estimate(int subdivisions) {
        if (subdivisions < 1 || subdivisions > 4)
            throw new IllegalArgumentException("subdivisions must be 1..4");
        int observed = intervals.size();
        if (observed < MIN_INLIERS) return new Estimate(observed, 0, 0, 0, 0, Reason.TOO_FEW);
        double[] ms = new double[observed];
        int at = 0;
        for (long value : intervals) ms[at++] = value / 1_000_000.0;
        Arrays.sort(ms);
        double median = median(ms);
        // Reject outliers around the median without letting a single double
        // click or lag spike distort the proposed tempo.
        double band = Math.max(10.0, median * 0.22);
        double sum = 0, sumSquares = 0;
        int inliers = 0;
        for (double sample : ms) {
            if (Math.abs(sample - median) > band) continue;
            inliers++;
            sum += sample;
            sumSquares += sample * sample;
        }
        if (inliers < MIN_INLIERS || inliers * 10 < observed * 7)
            return new Estimate(observed, inliers, 0, 0, 0, Reason.IRREGULAR);
        double mean = sum / inliers;
        double jitterMs = Math.sqrt(Math.max(0, sumSquares / inliers - mean * mean));
        double cps = 1000.0 / mean;
        if (jitterMs > Math.max(12.0, mean * 0.14))
            return new Estimate(observed, inliers, cps, jitterMs, 0, Reason.IRREGULAR);
        int bpm = (int) Math.round(60_000.0 / (mean * subdivisions));
        // Don't silently clamp the tempo: that would propose a rhythm different
        // from what the player actually tapped.
        if (bpm < 100 || bpm > 600)
            return new Estimate(observed, inliers, cps, jitterMs, 0, Reason.OUT_OF_RANGE);
        return new Estimate(observed, inliers, cps, jitterMs, bpm, Reason.READY);
    }

    private static double median(double[] sorted) {
        int n = sorted.length;
        return (n & 1) == 1 ? sorted[n / 2]
                : (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0;
    }

    public void clear() {
        intervals.clear();
        previousNs = Long.MIN_VALUE;
    }

    public enum Reason { READY, TOO_FEW, IRREGULAR, OUT_OF_RANGE }

    public record Estimate(int observedIntervals, int acceptedIntervals,
                           double cps, double jitterMs, int suggestedBpm, Reason reason) {
        public boolean ready() { return reason == Reason.READY; }
        public int pressesRemaining() { return Math.max(0, MIN_INLIERS - observedIntervals); }
    }
}
