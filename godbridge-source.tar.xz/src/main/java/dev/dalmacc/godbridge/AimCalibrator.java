package dev.dalmacc.godbridge;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * Suggests a personal training target from successful placements on the
 * highlighted side face. No automatic changes: the player must apply it.
 * Pure Java, bounded memory; median and inlier filtering resist stray clicks.
 */
public final class AimCalibrator {
    public static final int CAPACITY = 64;
    public static final int MIN_SAMPLES = 12;
    private static final double INLIER_RADIUS = 0.18;
    private final ArrayDeque<Point> samples = new ArrayDeque<>();

    private record Point(double u, double v) {}

    public record Estimate(int samples, int inliers, double u, double v,
                           double medianScatter, boolean reliable) {
        public int confidencePercent() {
            return samples == 0 ? 0 : (int) Math.round(100.0 * inliers / samples);
        }
    }

    public void record(double u, double v) {
        if (!Double.isFinite(u) || !Double.isFinite(v) || u < 0 || u > 1 || v < 0 || v > 1)
            return;
        if (samples.size() == CAPACITY) samples.removeFirst();
        samples.addLast(new Point(u, v));
    }

    public Estimate estimate() {
        int n = samples.size();
        if (n < MIN_SAMPLES) return new Estimate(n, 0, Double.NaN, Double.NaN, Double.NaN, false);
        double[] us = new double[n], vs = new double[n];
        int index = 0;
        for (Point p : samples) { us[index] = p.u(); vs[index++] = p.v(); }
        double centerU = median(us), centerV = median(vs);
        double[] inlierU = new double[n], inlierV = new double[n], distances = new double[n];
        int count = 0;
        for (Point p : samples) {
            double distance = Math.hypot(p.u() - centerU, p.v() - centerV);
            if (distance <= INLIER_RADIUS) {
                inlierU[count] = p.u();
                inlierV[count] = p.v();
                distances[count++] = distance;
            }
        }
        if (count == 0) return new Estimate(n, 0, centerU, centerV, Double.NaN, false);
        centerU = median(Arrays.copyOf(inlierU, count));
        centerV = median(Arrays.copyOf(inlierV, count));
        double scatter = median(Arrays.copyOf(distances, count));
        boolean reliable = count >= MIN_SAMPLES && count * 10 >= n * 7 &&
                centerU >= 0.10 && centerU <= 0.90 && centerV >= 0.70 && centerV <= 0.99;
        return new Estimate(n, count, centerU, centerV, scatter, reliable);
    }

    public void clear() { samples.clear(); }
    public int size() { return samples.size(); }

    private static double median(double[] values) {
        Arrays.sort(values);
        int mid = values.length / 2;
        return values.length % 2 == 0 ? (values[mid - 1] + values[mid]) * 0.5 : values[mid];
    }
}
