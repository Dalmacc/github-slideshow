package dev.dalmacc.godbridge;

/**
 * Measures click-to-metronome alignment separately from placement results.
 * A rhythm beat is a unique click slot; pressing twice in one slot never earns
 * two successes. Missing beats are only counted inside a burst, so leaving
 * the mouse untouched between attempts does not destroy the score.
 */
public final class BeatConsistency {
    public static final long BURST_PAUSE_NS = 700_000_000L;

    private long lastTimeNs = Long.MIN_VALUE;
    private long lastSlot = Long.MIN_VALUE;
    private int uniqueSlots;
    private int onTimeSlots;
    private int offTimeSlots;
    private int missedBeats;
    private int extraClicks;
    private int currentStreak;
    private int bestStreak;

    public void record(long timestampNs, long originNs, int bpm, int subdivisions,
                       int offsetMs, int toleranceMs) {
        long period = RhythmMath.clickPeriodNs(bpm, subdivisions);
        if (lastTimeNs != Long.MIN_VALUE && timestampNs <= lastTimeNs) return;
        long adjusted = timestampNs - originNs - offsetMs * 1_000_000L;
        // Rounded index of the nearest click subdivision; exact half-slots may
        // fall into the next beat. The tolerance can never extend that far.
        long slot = Math.floorDiv(adjusted + period / 2, period);
        int errorMs = RhythmMath.signedErrorMs(timestampNs, originNs, bpm, offsetMs, subdivisions);
        boolean onTime = Math.abs(errorMs) <=
                RhythmMath.effectiveToleranceMs(bpm, toleranceMs, subdivisions);
        boolean newBurst = lastTimeNs == Long.MIN_VALUE
                || timestampNs - lastTimeNs > BURST_PAUSE_NS;
        if (newBurst) {
            lastSlot = Long.MIN_VALUE;
            currentStreak = 0;
        }
        if (lastSlot != Long.MIN_VALUE) {
            if (slot <= lastSlot) {
                extraClicks++;
                currentStreak = 0;
                lastTimeNs = timestampNs;
                return;
            }
            long missed = slot - lastSlot - 1;
            if (missed > 0) {
                missedBeats += (int) Math.min(missed, Integer.MAX_VALUE - (long) missedBeats);
                currentStreak = 0;
            }
        }
        uniqueSlots++;
        if (onTime) {
            onTimeSlots++;
            currentStreak++;
            bestStreak = Math.max(currentStreak, bestStreak);
        } else {
            offTimeSlots++;
            currentStreak = 0;
        }
        lastSlot = slot;
        lastTimeNs = timestampNs;
    }

    /**
     * Forget the previous absolute slot after the render clock is re-anchored,
     * without throwing away session accuracy, misses or the best click streak.
     */
    public void startNewBurst() {
        lastTimeNs = Long.MIN_VALUE;
        lastSlot = Long.MIN_VALUE;
        currentStreak = 0;
    }

    public Snapshot snapshot() {
        return new Snapshot(uniqueSlots, onTimeSlots, offTimeSlots, missedBeats,
                extraClicks, currentStreak, bestStreak);
    }

    public void clear() {
        lastTimeNs = Long.MIN_VALUE;
        lastSlot = Long.MIN_VALUE;
        uniqueSlots = onTimeSlots = offTimeSlots = missedBeats = extraClicks = 0;
        currentStreak = bestStreak = 0;
    }

    public record Snapshot(int uniqueSlots, int onTimeSlots, int offTimeSlots, int missedBeats,
                           int extraClicks, int currentStreak, int bestStreak) {
        public int hitPercent() {
            int denominator = uniqueSlots + missedBeats + extraClicks;
            return denominator == 0 ? 0 : (int) Math.round(onTimeSlots * 100.0 / denominator);
        }
    }
}
