package dev.dalmacc.godbridge;

/**
 * Detects a suspension of world-render frames, e.g. after Alt-Tab or a long
 * graphics stall. Frame-limited sound is never queued or replayed in a burst.
 *
 * No threads, timers, or interaction with Minecraft: clock and scheduling
 * calculations are independent of both the HUD and the 20-TPS game loop.
 */
public final class MetronomeRecovery {
    public static final long STALL_THRESHOLD_NS = 350_000_000L;
    private long lastFrameNs = Long.MIN_VALUE;

    /**
     * @return true only after rendering has resumed following a prolonged gap.
     *         The initial frame merely initializes the tracker.
     */
    public boolean observeFrame(long nowNs) {
        if (lastFrameNs == Long.MIN_VALUE) {
            lastFrameNs = nowNs;
            return false;
        }
        long gap = nowNs - lastFrameNs;
        lastFrameNs = nowNs;
        return gap < 0L || gap >= STALL_THRESHOLD_NS;
    }

    /**
     * Pick an origin such that the next *audible* slot 0 will occur one full
     * click-period in the future, independently of a positive/negative audio
     * offset. We don't claim that an audio backend can play with zero latency.
     */
    public static long originForNextDownbeat(long nowNs, int bpm, int subdivisions, int audioOffsetMs) {
        long nextSoundNs = Math.addExact(nowNs, RhythmMath.clickPeriodNs(bpm, subdivisions));
        return Math.subtractExact(nextSoundNs, audioOffsetMs * 1_000_000L);
    }

    public void clear() {
        lastFrameNs = Long.MIN_VALUE;
    }
}
