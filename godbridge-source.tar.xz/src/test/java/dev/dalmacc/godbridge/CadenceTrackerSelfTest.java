package dev.dalmacc.godbridge;

/** Test realtime interval statistics without Minecraft and without a metronome. */
public final class CadenceTrackerSelfTest {
    private static void check(boolean c, String msg) {
        if (!c) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        CadenceTracker c = new CadenceTracker();
        long start = 1_000_000_000L;
        for (int i = 0; i <= 8; i++) c.record(start + i * 62_500_000L);
        var steady = c.recent(start + 8 * 62_500_000L, 16);
        check(steady.intervals() == 8, "eight intervals");
        check(Math.abs(steady.cps() - 16.0) < 1e-9, "real 16 CPS");
        check(steady.jitterMs() < 0.00001, "steady intervals have zero deviation");
        c.record(start + 3 * 62_500_000L); // ignore nonmonotonic event
        check(c.recent(start + 8 * 62_500_000L, 16).intervals() == 8,
                "out-of-order input ignored");
        check(c.recent(start + 8 * 62_500_000L + 500_000_000L, 16).intervals() == 0,
                "stale CPS disappears after pause");
        c.record(start + 8 * 62_500_000L + 800_000_000L);
        c.record(start + 8 * 62_500_000L + 900_000_000L);
        var nextBurst = c.recent(start + 8 * 62_500_000L + 900_000_000L, 16);
        check(nextBurst.intervals() == 1 && Math.abs(nextBurst.cps() - 10.0) < 0.0001,
                "new burst is isolated from prior rhythm");
        c.clear();
        check(c.recent(start, 16).intervals() == 0, "clear removes all data");
        System.out.println("CadenceTrackerSelfTest PASS");
    }
}
