package dev.dalmacc.godbridge;

/** Dependency-free test of the high-resolution clock calculations. */
public final class RhythmMathSelfTest {
    private static void equal(int expected, int actual) {
        if (expected != actual) throw new AssertionError("expected " + expected + ", got " + actual);
    }

    private static void close(double expected, double actual, double epsilon) {
        if (Math.abs(expected - actual) > epsilon) throw new AssertionError("expected " + expected + ", got " + actual);
    }

    public static void main(String[] args) {
        equal(250_000_000, (int) RhythmMath.beatPeriodNs(240));
        equal(0, RhythmMath.signedErrorMs(1_000_000_000L, 1_000_000_000L, 240, 0));
        equal(20, RhythmMath.signedErrorMs(1_020_000_000L, 1_000_000_000L, 240, 0));
        equal(-20, RhythmMath.signedErrorMs(980_000_000L, 1_000_000_000L, 240, 0));
        equal(-20, RhythmMath.signedErrorMs(1_230_000_000L, 1_000_000_000L, 240, 0));
        equal(0, RhythmMath.signedErrorMs(1_025_000_000L, 1_000_000_000L, 240, 25));
        close(0.5, RhythmMath.beatPhase(1_125_000_000L, 1_000_000_000L, 240), 0.0001);
        System.out.println("RhythmMathSelfTest PASS");
    }
}
