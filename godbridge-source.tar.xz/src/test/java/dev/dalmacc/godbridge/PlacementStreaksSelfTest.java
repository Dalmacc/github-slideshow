package dev.dalmacc.godbridge;

public final class PlacementStreaksSelfTest {
    private static void expect(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }

    private static AttemptHistory.Entry click(AttemptHistory history, int i) {
        return history.begin(i * 1_000_000_000L, 240, 4, 0, true, true, 0);
    }

    public static void main(String[] args) {
        AttemptHistory history = new AttemptHistory();
        var first = click(history, 1);
        var second = click(history, 2);
        var third = click(history, 3);
        history.resolve(third, AttemptHistory.Outcome.PLACED, 12);
        var out = PlacementStreaks.evaluate(history.snapshot(), 0);
        expect(out.current() == 1 && out.longest() == 1, "pending clicks split confirmed chain");
        history.resolve(first, AttemptHistory.Outcome.PLACED, 9);
        out = PlacementStreaks.evaluate(history.snapshot(), 0);
        expect(out.current() == 1 && out.longest() == 1, "late confirmation cannot jump pending gap");
        history.resolve(second, AttemptHistory.Outcome.PLACED, 50);
        out = PlacementStreaks.evaluate(history.snapshot(), 0);
        expect(out.current() == 3 && out.longest() == 3, "reordered confirmations eventually form chain");

        var fail = click(history, 4);
        var delayed = click(history, 5);
        history.resolve(fail, AttemptHistory.Outcome.MISS, -1);
        history.resolve(delayed, AttemptHistory.Outcome.PLACED, 11);
        out = PlacementStreaks.evaluate(history.snapshot(), 0);
        expect(out.current() == 1 && out.longest() == 3, "failure breaks run in input order");

        // Regression: earlier pending block resolves AFTER later miss.
        history = new AttemptHistory();
        var slow = click(history, 1);
        var miss = click(history, 2);
        history.resolve(miss, AttemptHistory.Outcome.WRONG_FACE, -1);
        history.resolve(slow, AttemptHistory.Outcome.PLACED, 900);
        out = PlacementStreaks.evaluate(history.snapshot(), 0);
        expect(out.current() == 0, "late old success must not restore streak after miss");

        var overlap = click(history, 3);
        history.resolve(overlap, AttemptHistory.Outcome.OVERLAP, -1);
        expect(PlacementStreaks.evaluate(history.snapshot(), 0).current() == 0,
                "extra click alone cannot revive streak");
        var placed = click(history, 4);
        history.resolve(placed, AttemptHistory.Outcome.PLACED, 50);
        expect(PlacementStreaks.evaluate(history.snapshot(), 0).current() == 1,
                "neutral result does not penalize subsequent placement");
        expect(PlacementStreaks.evaluate(history.snapshot(), 4).current() == 0,
                "fall/pause epoch barrier discards old chain");
        var newPlaced = click(history, 5);
        history.resolve(newPlaced, AttemptHistory.Outcome.PLACED, 50);
        expect(PlacementStreaks.evaluate(history.snapshot(), 4).current() == 1,
                "new epoch starts its own streak");
        System.out.println("PlacementStreaksSelfTest PASS");
    }
}
