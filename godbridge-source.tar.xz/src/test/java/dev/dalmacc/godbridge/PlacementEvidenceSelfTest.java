package dev.dalmacc.godbridge;

public final class PlacementEvidenceSelfTest {
    private static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        var success = new PlacementEvidence(30, 2);
        check(success.observe(true, false) == PlacementEvidence.Verdict.WAITING, "empty cell");
        check(success.observe(false, true) == PlacementEvidence.Verdict.WAITING, "first predicted tick");
        check(success.observe(false, true) == PlacementEvidence.Verdict.MATCH, "second matching tick");
        check(success.observe(true, false) == PlacementEvidence.Verdict.MATCH, "resolved verdict immutable");

        var rollback = new PlacementEvidence(30, 2);
        check(rollback.observe(false, true) == PlacementEvidence.Verdict.WAITING, "prediction starts");
        check(rollback.observe(true, false) == PlacementEvidence.Verdict.WAITING, "prediction rolls back");
        check(rollback.observe(false, true) == PlacementEvidence.Verdict.WAITING, "streak reset");
        check(rollback.observe(false, true) == PlacementEvidence.Verdict.MATCH, "stable after rollback");

        var other = new PlacementEvidence(30, 2);
        check(other.observe(false, false) == PlacementEvidence.Verdict.WAITING, "other block first tick");
        check(other.observe(false, false) == PlacementEvidence.Verdict.OTHER_BLOCK, "other block ambiguous");

        var transientOther = new PlacementEvidence(30, 2);
        check(transientOther.observe(false, false) == PlacementEvidence.Verdict.WAITING, "foreign transient");
        check(transientOther.observe(false, true) == PlacementEvidence.Verdict.WAITING, "different state transitions");
        check(transientOther.observe(false, true) == PlacementEvidence.Verdict.MATCH, "new expected stable");

        var timeout = new PlacementEvidence(3, 2);
        check(timeout.observe(true, false) == PlacementEvidence.Verdict.WAITING, "timeout tick1");
        check(timeout.observe(true, false) == PlacementEvidence.Verdict.WAITING, "timeout tick2");
        check(timeout.observe(true, false) == PlacementEvidence.Verdict.TIMEOUT, "timeout tick3");

        boolean rejected = false;
        try { new PlacementEvidence(1, 2); } catch (IllegalArgumentException ex) { rejected = true; }
        check(rejected, "invalid thresholds rejected");
        System.out.println("PlacementEvidenceSelfTest PASS");
    }
}
