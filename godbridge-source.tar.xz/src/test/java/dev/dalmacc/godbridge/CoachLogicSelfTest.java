package dev.dalmacc.godbridge;

import java.util.List;

/** Tests that work without Minecraft, Fabric, Gradle or network connectivity. */
public final class CoachLogicSelfTest {
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
    }

    public static void main(String[] args) {
        ClickEvaluationSelfTest.main(args);
        ScreenAimDirectionSelfTest.main(args);
        AimCalibratorSelfTest.main(args);
        RhythmMathSelfTest.main(args);
        RhythmSubdivisionSelfTest.main(args);
        CadenceTrackerSelfTest.main(args);
        BeatConsistencySelfTest.main(args);
        AttemptHistorySelfTest.main(args);
        PlacementEvidenceSelfTest.main(args);
        GuideGeometrySelfTest.main(args);
        check(RhythmMath.beatPeriodNs(600) == 100_000_000L, "600 BPM period");
        check(RhythmMath.effectiveToleranceMs(600, 65) == 25, "high-BPM tolerance");
        check(RhythmMath.effectiveToleranceMs(240, 65) == 62, "low-BPM tolerance");
        check(RhythmMath.effectiveToleranceMs(240, 20) == 20, "configured strict tolerance");
        check(RhythmMath.signedErrorMs(1_230_000_000L, 1_000_000_000L, 240, 0) == -20, "wraparound early click");
        check(RhythmMath.signedErrorMs(1_270_000_000L, 1_000_000_000L, 240, 0) == 20, "wraparound late click");
        check(AngleMath.diagonalDeviation(135.0) == 0, "angle 135");
        check(AngleMath.diagonalDeviation(-45.0) == 0, "angle -45");
        check(Math.abs(AngleMath.diagonalDeviation(130.0) - 5.0) < 0.00001, "angle correction");

        AimHistory heat = new AimHistory();
        AimHistory.Sample first = heat.record(0.5, 0.96);
        heat.resolve(first, true);
        check(first.outcome() == AimHistory.Outcome.PLACED, "successful mark");
        AimHistory.Sample bad = heat.record(-10, 10);
        heat.resolve(bad, false);
        check(bad.u == 0 && bad.v == 1, "normalized bounds");
        check(bad.outcome() == AimHistory.Outcome.FAILED, "failure mark");
        for (int i = 0; i < 200; i++) heat.record(i / 200.0, 0.25);
        List<AimHistory.Sample> snapshot = heat.snapshot();
        check(heat.size() == AimHistory.MAX_SAMPLES, "bounded history");
        check(Math.abs(snapshot.get(0).u - 152 / 200.0) < 0.00001, "oldest evicted");
        check(Math.abs(snapshot.get(snapshot.size() - 1).u - 199 / 200.0) < 0.00001, "last retained");
        heat.clear();
        check(heat.size() == 0, "reset history");
        System.out.println("CoachLogicSelfTest PASS");
    }
}
