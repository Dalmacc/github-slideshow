package dev.dalmacc.godbridge;

public final class PulseDeliverySelfTest {
    private static void expect(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        var p = new PulseDelivery();
        expect(p.advance(0), "initial click plays");
        expect(!p.advance(0), "same frame beat never plays twice");
        for (int i = 1; i <= 15; i++) expect(p.advance(i), "smooth metronome plays");
        expect(p.snapshot().missedPulses() == 0 && !p.snapshot().frameLimited(),
                "steady FPS never warns");
        p.clear();
        for (int i = 0; i < 16; i += 2) expect(p.advance(i), "even slots play");
        expect(p.snapshot().missedPulses() == 7, "one missing pulse per lost render");
        expect(p.snapshot().missPercent() == 47 && p.snapshot().frameLimited(),
                "low FPS metronome misses are visible");
        expect(p.advance(500), "long lag resumes with one pulse");
        expect(p.snapshot().missedPulses() == 0 && !p.snapshot().frameLimited(),
                "menu/alt tab gap does not count as hundreds of misses");
        p.clear();
        expect(p.isUninitialized(), "clear permits fresh sound start");
        p.prime(4);
        expect(!p.isUninitialized(), "priming marks the current audio slot");
        expect(!p.advance(4), "no phantom sound inside an offset slot");
        expect(p.advance(5), "first future pulse after priming plays");
        p.clear();
        expect(p.advance(5) && p.advance(1) && p.snapshot().missedPulses() == 0,
                "backward beat phase resets safely");
        for (int i = 0; i < 100; i++) p.advance(i);
        expect(p.snapshot().renderedPulses() == 32, "memory is bounded");
        System.out.println("PulseDeliverySelfTest PASS");
    }
}
