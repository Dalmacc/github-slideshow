package dev.dalmacc.godbridge;

import static dev.dalmacc.godbridge.ScreenAimDirection.Cue;

public final class ScreenAimDirectionSelfTest {
    private static void expect(Cue expected, double x, double y) {
        Cue actual = ScreenAimDirection.cue(x, y, 160, 90, 6);
        if (actual != expected) throw new AssertionError("expected " + expected + ", got " + actual + ": " + x + "," + y);
    }

    public static void main(String[] args) {
        expect(Cue.CENTERED, 160, 90);
        expect(Cue.CENTERED, 154, 96); // threshold inclusive
        expect(Cue.UP, 160, 80);
        expect(Cue.DOWN, 160, 100);
        expect(Cue.LEFT, 150, 90);
        expect(Cue.RIGHT, 170, 90);
        expect(Cue.UP_LEFT, 150, 80);
        expect(Cue.UP_RIGHT, 170, 80);
        expect(Cue.DOWN_LEFT, 150, 100);
        expect(Cue.DOWN_RIGHT, 170, 100);
        expect(Cue.RIGHT, 170, 95);
        try {
            ScreenAimDirection.cue(Double.NaN, 90, 160, 90, 6);
            throw new AssertionError("NaN point should be rejected");
        } catch (IllegalArgumentException expected) { /* pass */ }
        try {
            ScreenAimDirection.cue(160, 90, 160, 90, -1);
            throw new AssertionError("negative dead zone should be rejected");
        } catch (IllegalArgumentException expected) { /* pass */ }
        System.out.println("ScreenAimDirectionSelfTest PASS");
    }
}
