package dev.dalmacc.godbridge;

/** Pure click-grid tests: no Minecraft classes or timing sleeps. */
public final class BeatConsistencySelfTest {
    private static void check(boolean ok, String note) {
        if (!ok) throw new AssertionError(note);
    }
    public static void main(String[] args) {
        long origin = 1_000_000_000L;
        long period = RhythmMath.clickPeriodNs(240, 4);
        check(period == 62_500_000L, "240 BPM times four = 16 CPS");
        BeatConsistency meter = new BeatConsistency();
        meter.record(origin, origin, 240, 4, 0, 65);
        meter.record(origin + period, origin, 240, 4, 0, 65);
        meter.record(origin + 3 * period, origin, 240, 4, 0, 65);
        meter.record(origin + 3 * period + 4_000_000, origin, 240, 4, 0, 65);
        var r = meter.snapshot();
        check(r.uniqueSlots() == 3, "unique click slots");
        check(r.onTimeSlots() == 3, "on-time slots");
        check(r.missedBeats() == 1, "skipped a beat despite on-time clicks");
        check(r.extraClicks() == 1, "double click in same beat is not a success");
        check(r.hitPercent() == 60, "coverage penalizes skipped/extra beats");
        check(r.bestStreak() == 2, "two initial clean beats");
        // 20ms past a 62.5ms beat exceeds its 15ms tolerance.
        meter.record(origin + 4 * period + 20_000_000L, origin, 240, 4, 0, 65);
        r = meter.snapshot();
        check(r.offTimeSlots() == 1 && r.currentStreak() == 0, "offbeat resets streak");
        int missed = r.missedBeats();
        int unique = r.uniqueSlots();
        meter.record(origin + 1_250_000_000L, origin, 240, 4, 0, 65);
        check(meter.snapshot().missedBeats() == missed, "idle gap cannot flood skipped beats");
        check(meter.snapshot().uniqueSlots() == unique + 1, "new burst first click is counted");
        meter.record(origin + 1_250_000_000L - 10, origin, 240, 4, 0, 65);
        check(meter.snapshot().uniqueSlots() == unique + 1, "out-of-order clock ignored");
        meter.clear();
        check(meter.snapshot().uniqueSlots() == 0, "reset clears history");
        meter.record(origin + period + 10_000_000L, origin, 240, 4, 10, 65);
        check(meter.snapshot().onTimeSlots() == 1, "offset aligns slot");
        System.out.println("BeatConsistencySelfTest PASS");
    }
}
