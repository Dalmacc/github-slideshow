package dev.dalmacc.godbridge;

/** Regression: graphics stalls should not be counted as valid played pulses. */
public final class MetronomeRecoverySelfTest {
    private static void check(boolean pass, String why) {
        if (!pass) throw new AssertionError(why);
    }

    public static void main(String[] args) {
        MetronomeRecovery recovery = new MetronomeRecovery();
        long now = 5_000_000_000L;
        check(!recovery.observeFrame(now), "first frame just arms the clock");
        for (int i = 1; i <= 144; i++) {
            check(!recovery.observeFrame(now + i * 6_944_444L), "144 FPS is normal");
        }
        now += 144L * 6_944_444L;
        check(!recovery.observeFrame(now + 100_000_000L), "10 FPS is not Alt-Tab");
        check(!recovery.observeFrame(now + 349_999_999L), "sub-350-ms gap must not restart tempo");
        check(recovery.observeFrame(now + 800_000_000L), "long rendering stall must recover");
        check(!recovery.observeFrame(now + 809_000_000L), "only one restart per stall");

        final int bpm = 260, subdivision = 4;
        final long period = RhythmMath.clickPeriodNs(bpm, subdivision);
        for (int offsetMs : new int[] {-200, -75, 0, 70, 200}) {
            long resumeNs = 8_000_000_000L;
            long newOrigin = MetronomeRecovery.originForNextDownbeat(resumeNs, bpm, subdivision, offsetMs);
            long before = MetronomeTimeline.slotIndex(resumeNs, newOrigin, bpm, subdivision, offsetMs);
            long first = MetronomeTimeline.slotIndex(resumeNs + period, newOrigin, bpm, subdivision, offsetMs);
            check(before == -1L, "don't play a phantom sound on resume; offset=" + offsetMs);
            check(first == 0L, "new downbeat must align with sound offset=" + offsetMs);
            PulseDelivery pulse = new PulseDelivery();
            pulse.prime(-1L);
            check(!pulse.advance(before), "silent recovery slot");
            check(pulse.advance(first), "play the first new downbeat");
            check(pulse.snapshot().missedPulses() == 0, "stall isn't a skipped beat");
        }
        // A changed beat origin must start a NEW series of slot numbers.
        // The 400-ms freeze falls below BeatConsistency's ordinary 700-ms
        // idle threshold, so without the explicit split it is misclassified
        // as an extra click (new slot 0 <= old slot).
        BeatConsistency consistency = new BeatConsistency();
        long originA = 7_000_000_000L;
        consistency.record(originA, originA, 260, 4, 0, 65);
        consistency.record(originA + period, originA, 260, 4, 0, 65);
        var beforeScore = consistency.snapshot();
        consistency.startNewBurst();
        long originB = originA + 400_000_000L + period;
        consistency.record(originB, originB, 260, 4, 0, 65);
        var afterScore = consistency.snapshot();
        check(afterScore.extraClicks() == beforeScore.extraClicks(), "new clock is not an extra click");
        check(afterScore.uniqueSlots() == beforeScore.uniqueSlots() + 1, "preserve previous accuracy");
        check(afterScore.bestStreak() == beforeScore.bestStreak(), "preserve best streak");

        recovery.clear();
        check(!recovery.observeFrame(20_000_000_000L), "GUI reset arms a new frame stream");
        System.out.println("MetronomeRecoverySelfTest PASS");
    }
}
