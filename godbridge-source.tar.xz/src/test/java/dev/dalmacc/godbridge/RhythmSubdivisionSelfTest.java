package dev.dalmacc.godbridge;

/** High-CPS click subdivisions are judged against *click*, not quarter-note, periods. */
public final class RhythmSubdivisionSelfTest {
    private static void check(boolean c, String msg) {
        if (!c) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        long start = 1_000_000_000L;
        check(RhythmMath.clickPeriodNs(240, 4) == 62_500_000L, "16 CPS period");
        check(RhythmMath.clickPeriodNs(240, 2) == 125_000_000L, "8 CPS period");
        check(Math.abs(RhythmMath.targetCps(260, 4) - 17.333333333) < 1e-7, "17.33 CPS target");
        check(RhythmMath.effectiveToleranceMs(240, 65, 4) == 15, "click-level acceptance window");
        check(RhythmMath.signedErrorMs(start + 4 * 62_500_000L, start, 240, 0, 4) == 0,
                "beat boundary");
        check(RhythmMath.signedErrorMs(start + 62_500_000L + 10_000_000L,
                start, 240, 0, 4) == 10, "10ms late");
        check(RhythmMath.signedErrorMs(start + 62_500_000L - 10_000_000L,
                start, 240, 0, 4) == -10, "10ms early");
        check(RhythmMath.signedErrorMs(start + 62_500_000L + 20_000_000L,
                start, 240, 20, 4) == 0, "calibrated input offset");
        check(Math.abs(RhythmMath.clickPhase(start + 62_500_000L + 20_000_000L,
                start, 240, 20, 4)) < 1e-6, "HUD phase matches click evaluation");
        for (int bad : new int[]{0, -1, 5}) {
            try {
                RhythmMath.clickPeriodNs(240, bad);
                throw new AssertionError("accepted invalid subdivisions " + bad);
            } catch (IllegalArgumentException expected) { /* good */ }
        }
        System.out.println("RhythmSubdivisionSelfTest PASS");
    }
}
