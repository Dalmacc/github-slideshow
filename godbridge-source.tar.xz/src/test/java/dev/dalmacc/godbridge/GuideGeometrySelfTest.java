package dev.dalmacc.godbridge;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/** Checks that the user-adjustable weak spot matches the normalized heatmap on every side. */
public final class GuideGeometrySelfTest {
    private static void close(double expected, double actual, String note) {
        if (Math.abs(actual - expected) > 1e-7) throw new AssertionError(note + ": " + actual + " != " + expected);
    }
    public static void main(String[] args) {
        BlockPos pos = new BlockPos(10, 64, -3);
        Direction[] faces = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        for (Direction face : faces) {
            for (double u : new double[]{0.1, 0.25, 0.5, 0.75, 0.9}) {
                for (double v : new double[]{0.70, 0.89, 0.96875, 0.99}) {
                    Vec3 point = GuideTarget.guidePoint(pos, face, u, v);
                    close(u, GuideTarget.faceU(point, pos, face), "horizontal map " + face);
                    close(v, GuideTarget.faceV(point, pos), "vertical map " + face);
                    close(0, GuideTarget.planarError(point, pos, face, u, v), "zero error " + face);
                    close(pos.getY() + v, point.y, "height " + face);
                    if (face.getStepX() != 0) close(pos.getX() + (face.getStepX() > 0 ? 1 : 0),
                            point.x, "X-face plane");
                    else close(pos.getZ() + (face.getStepZ() > 0 ? 1 : 0),
                            point.z, "Z-face plane");
                }
            }
        }
        try {
            GuideTarget.guidePoint(pos, Direction.UP, 0.5, 0.9);
            throw new AssertionError("UP must not be accepted as a side face");
        } catch (IllegalArgumentException expected) { /* correct */ }
        System.out.println("GuideGeometrySelfTest PASS");
    }
}
