package dev.dalmacc.godbridge;

/** Regression: late world update must use criteria from press, not current F9 settings. */
public final class ClickEvaluationSelfTest {
    public static void main(String[] args) {
        ClickEvaluation click = new ClickEvaluation(true, 240, 4, 40, .50, .97, .10);
        // Player changes BPM, tolerance, and the guide position while the
        // attempted placement is still pending. Those changes may not alter it.
        int currentBpm = 100;
        int currentTolerance = 200;
        double currentGuide = .20;
        double currentAimTolerance = .45;
        check(click.evaluate(42, .02) == ClickEvaluation.Issue.LATE, "late under effective 15 ms cap");
        check(click.evaluate(-42, .02) == ClickEvaluation.Issue.EARLY, "early under effective 15 ms cap");
        check(click.evaluate(10, .12) == ClickEvaluation.Issue.AIM, "original 0.10 aim threshold");
        check(click.evaluate(10, .05) == ClickEvaluation.Issue.NONE, "within both effective windows");
        check(click.guideLateral() == .5 && click.guideHeight() == .97, "saved aim target");
        check(currentBpm != click.bpm() && currentTolerance != click.timingToleranceMs()
                && currentGuide != click.guideLateral() && currentAimTolerance != click.aimTolerance(),
                "current settings are different for this test");
        ClickEvaluation noMetronome = new ClickEvaluation(false, 240, 4, 40, .5, .97, .10);
        check(noMetronome.evaluate(100, .02) == ClickEvaluation.Issue.NONE, "metronome disabled at press");
        check(noMetronome.evaluate(100, .12) == ClickEvaluation.Issue.AIM, "aim independent from metronome");
        System.out.println("ClickEvaluationSelfTest PASS");
    }

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
