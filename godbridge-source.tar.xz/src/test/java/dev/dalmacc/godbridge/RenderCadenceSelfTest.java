package dev.dalmacc.godbridge;

/** Render-driven audio cadence, deliberately independent of 20 TPS game ticks
 *  and HUD visibility. Tests pure timing; does not exercise the Fabric callback. */
public final class RenderCadenceSelfTest {
    private static void require(boolean condition, String detail) {
        if (!condition) throw new AssertionError(detail);
    }

    private static PulseDelivery simulateFrames(int fps, int durationSeconds, int bpm, int subdivisions) {
        PulseDelivery pulses = new PulseDelivery();
        long origin = 1_000_000_000L;
        int frameCount = fps * durationSeconds;
        for (int frame = 0; frame < frameCount; frame++) {
            long timestamp = origin + Math.round(frame * 1_000_000_000.0 / fps);
            long slot = MetronomeTimeline.slotIndex(timestamp, origin, bpm, subdivisions, 0);
            pulses.advance(slot);
        }
        return pulses;
    }

    public static void main(String[] args) {
        // 260 BPM x4 ~17.33 clicks/s. A 144 FPS world render loop can
        // schedule every pulse even if the user hides the game HUD with F1.
        // This model has no HUD calls, on purpose.
        PulseDelivery fast = simulateFrames(144, 1, 260, 4);
        PulseDelivery.Snapshot fastResult = fast.snapshot();
        require(fastResult.renderedPulses() >= 17 && fastResult.renderedPulses() <= 18,
                "144 FPS should deliver about 17-18 metronome pulses per second");
        require(fastResult.missedPulses() == 0, "144 FPS should not skip any 17 CPS pulses");

        // Rendering, not 20 TPS, is the timing limit. If the actual game
        // renders at 10 FPS, detecting dropped pulses must still work.
        PulseDelivery slow = simulateFrames(10, 1, 260, 4);
        require(slow.snapshot().missedPulses() >= 5, "10 FPS must report skipped pulses");
        require(slow.snapshot().frameLimited(), "low-FPS warning should activate");

        // Returning from a menu resets the stream rather than playing all
        // missed beats in a burst after unpausing.
        slow.clear();
        require(slow.snapshot().missedPulses() == 0, "resync should clear old misses");
        System.out.println("RenderCadenceSelfTest PASS");
    }
}
