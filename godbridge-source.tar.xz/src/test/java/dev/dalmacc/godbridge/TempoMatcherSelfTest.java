package dev.dalmacc.godbridge;

public final class TempoMatcherSelfTest {
    public static void main(String[] args) {
        TempoMatcher t = new TempoMatcher();
        check(t.estimate(4).reason() == TempoMatcher.Reason.TOO_FEW, "empty session");
        long now = 1_000_000_000L;
        for (int i = 0; i < 13; i++) {
            t.record(now);
            now += 100_000_000L;
        }
        var stable = t.estimate(4);
        check(stable.ready(), "stable click burst should be reliable");
        check(stable.suggestedBpm() == 150, "10 CPS with x4 = 150 BPM");
        check(stable.observedIntervals() == 12, "12 intervals");
        check(t.estimate(2).suggestedBpm() == 300, "10 CPS with x2 = 300 BPM");
        check(t.estimate(1).suggestedBpm() == 600, "10 CPS with x1 = 600 BPM");

        // A near-simultaneous duplicate event does not advance the reference click.
        t.record(now - 80_000_000L);
        check(t.estimate(4).suggestedBpm() == 150, "duplicate event ignored");
        // One delayed press should be rejected, not skew BPM.
        t.record(now + 250_000_000L);
        now += 350_000_000L;
        for (int i = 0; i < 10; i++, now += 100_000_000L) t.record(now);
        check(t.estimate(4).ready(), "one outlier should be harmless");
        check(Math.abs(t.estimate(4).suggestedBpm() - 150) <= 1, "robust BPM after outlier");

        // A long break starts a new burst; the old rhythm does not leak.
        now += 1_000_000_000L;
        t.record(now);
        check(t.estimate(4).reason() == TempoMatcher.Reason.TOO_FEW, "break clears old burst");
        for (int i = 1; i < 11; i++) t.record(now + i * 50_000_000L);
        check(t.estimate(4).suggestedBpm() == 300, "20 CPS with x4 = 300 BPM");

        t.clear();
        now += 3_000_000_000L;
        for (int i = 0; i < 10; i++) t.record(now + i * 400_000_000L);
        check(t.estimate(4).reason() == TempoMatcher.Reason.OUT_OF_RANGE,
                "too slow for 100 BPM x4 must not be silently clamped");

        t.clear();
        now += 8_000_000_000L;
        long clock = now;
        for (int i = 0; i < 14; i++) {
            t.record(clock);
            clock += i % 2 == 0 ? 55_000_000L : 140_000_000L;
        }
        check(t.estimate(4).reason() == TempoMatcher.Reason.IRREGULAR,
                "alternating unsteady intervals must not be auto-matched");
        try {
            t.estimate(0);
            throw new AssertionError("invalid subdivisions accepted");
        } catch (IllegalArgumentException expected) { /* expected */ }
        System.out.println("TempoMatcherSelfTest PASS");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
