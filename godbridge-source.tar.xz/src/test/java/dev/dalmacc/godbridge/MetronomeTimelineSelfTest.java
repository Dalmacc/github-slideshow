package dev.dalmacc.godbridge;

/** Pure clock regressions: no actual audio device or Minecraft dependency. */
public final class MetronomeTimelineSelfTest {
    private static void check(boolean ok, String reason) {
        if (!ok) throw new AssertionError(reason);
    }
    private static void close(double actual, double expected, String reason) {
        check(Math.abs(actual - expected) < 0.0000001, reason + " (" + actual + ")");
    }
    public static void main(String[] args) {
        long origin = 5_000_000_000L;
        int bpm = 240, divisions = 4;
        long period = RhythmMath.clickPeriodNs(bpm, divisions);
        check(period == 62_500_000L, "16 CPS test clock");
        check(MetronomeTimeline.slotIndex(origin, origin, bpm, divisions, 0) == 0, "pulse begins at origin");
        check(MetronomeTimeline.slotIndex(origin + period, origin, bpm, divisions, 0) == 1, "second pulse");
        check(MetronomeTimeline.slotIndex(origin - 1, origin, bpm, divisions, 0) == -1, "pre-origin pulse");
        check(MetronomeTimeline.slotIndex(origin + period * 4, origin, bpm, divisions, 0) == 4, "quarter boundary");
        close(MetronomeTimeline.quarterPhase(origin, origin, bpm, divisions, 0), 0, "initial quarter phase");
        close(MetronomeTimeline.quarterPhase(origin + period, origin, bpm, divisions, 0), .25, "first subdivision");
        close(MetronomeTimeline.quarterPhase(origin + 2 * period, origin, bpm, divisions, 0), .50, "second subdivision");
        close(MetronomeTimeline.quarterPhase(origin + 3 * period, origin, bpm, divisions, 0), .75, "third subdivision");
        close(MetronomeTimeline.quarterPhase(origin + 4 * period, origin, bpm, divisions, 0), 0, "wrap without drift");
        // Grading calibration should NOT move the sound; configurable sound offset should.
        int gradingOffset = 30;
        long gradedTime = origin + 30_000_000L;
        check(RhythmMath.signedErrorMs(gradedTime, origin, bpm, gradingOffset, divisions) == 0,
                "user input calibrated 30ms after bare audible beat");
        check(MetronomeTimeline.slotIndex(gradedTime - 1, origin, bpm, divisions, gradingOffset) == -1,
                "graded beat has its own boundary");
        check(MetronomeTimeline.slotIndex(gradedTime, origin, bpm, divisions, gradingOffset) == 0,
                "graded beat begins at calibration offset");
        check(MetronomeTimeline.slotIndex(origin, origin, bpm, divisions, 0) == 0,
                "sound offset independently defaults to zero");
        check(MetronomeTimeline.slotIndex(gradedTime, origin, bpm, divisions, gradingOffset) == 0,
                "audio can optionally follow click grading when both offsets match");
        check(MetronomeTimeline.slotIndex(origin - 20_000_000L, origin, bpm, divisions, -20) == 0,
                "negative audible offset advances a pulse");
        close(MetronomeTimeline.quarterPhase(origin - 20_000_000L, origin, bpm, divisions, -20),
                0, "negative offset positions cursor correctly");
        check(MetronomeTimeline.downbeat(-4, 4), "negative-index quarter accent");
        check(!MetronomeTimeline.downbeat(-3, 4), "not every subdivision accented");
        check(MetronomeTimeline.accentedBeat(-16, 4), "four-quarter accented beat");
        check(!MetronomeTimeline.accentedBeat(-4, 4), "regular quarter is less accented");
        check(RhythmMath.clickPeriodNs(600, 4) == 25_000_000L, "40 CPS high tempo");
        System.out.println("MetronomeTimelineSelfTest PASS");
    }
}
