package dev.dalmacc.godbridge;

/** Pure-Java regression tests for opt-in, outlier-resistant aim calibration. */
public final class AimCalibratorSelfTest {
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        AimCalibrator c = new AimCalibrator();
        c.record(Double.NaN, 0.9);
        c.record(Double.POSITIVE_INFINITY, 0.9);
        c.record(-1, 0.9);
        check(c.size() == 0, "reject invalid coordinates");
        for (int i = 0; i < 11; i++) c.record(0.61, 0.95);
        check(!c.estimate().reliable(), "require 12 successful samples");
        for (int i = 11; i < 32; i++) c.record(0.60 + (i % 3) * 0.01, 0.94 + (i % 4) * 0.007);
        for (int i = 0; i < 8; i++) c.record(i % 2 == 0 ? 0.05 : 0.98, 0.1);
        AimCalibrator.Estimate e = c.estimate();
        check(e.reliable(), "strong single cluster with outliers");
        check(Math.abs(e.u() - 0.61) < 0.03 && Math.abs(e.v() - 0.95) < 0.03,
                "robust center");
        check(e.confidencePercent() >= 75 && e.confidencePercent() <= 85, "inlier confidence");
        for (int i = 0; i < 90; i++) c.record(i % 2 == 0 ? 0.08 : 0.95,
                i % 3 == 0 ? 0.15 : 0.55);
        check(c.size() == AimCalibrator.CAPACITY, "fixed sample history capacity");
        check(!c.estimate().reliable(), "split or low-height aim is not suggested");
        c.clear();
        check(c.size() == 0 && !c.estimate().reliable(), "reset");
        System.out.println("AimCalibratorSelfTest PASS");
    }
}
