package dev.dalmacc.godbridge;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Deterministic client-only coaching and CSV report tests. */
public final class AttemptHistorySelfTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        AttemptHistory history = new AttemptHistory();
        AttemptHistory.Entry p = history.begin(10_000_000_000L, 240, 5, true, true, 3.0);
        history.recordAim(p, 0.52, 0.95, 0.03);
        history.resolve(p, AttemptHistory.Outcome.PLACED, 40);
        history.resolve(p, AttemptHistory.Outcome.MISS, -1); // once resolved, cannot change
        check(p.outcome() == AttemptHistory.Outcome.PLACED, "success cannot be overwritten");
        check(history.offsetMs(p) == 0, "relative session origin");

        AttemptHistory.Entry miss = history.begin(10_020_000_000L, 240, 80, true, false, 14);
        history.resolve(miss, AttemptHistory.Outcome.MISS, -1);
        AttemptHistory.Entry canceled = history.begin(10_030_000_000L, 240, 0, true, false, 0);
        history.resolve(canceled, AttemptHistory.Outcome.CANCELED, -1);
        AttemptHistory.Entry unconfirmed = history.begin(10_040_000_000L, 240, 4,
                0, true, true, 0);
        history.resolve(unconfirmed, AttemptHistory.Outcome.TIMEOUT, -1);
        AttemptHistory.Entry otherBlock = history.begin(10_045_000_000L, 240, 4,
                0, true, true, 0);
        history.resolve(otherBlock, AttemptHistory.Outcome.OTHER_BLOCK, -1);
        AttemptHistory.Entry overlap = history.begin(10_050_000_000L, 240, 4,
                0, true, true, 0);
        history.resolve(overlap, AttemptHistory.Outcome.OVERLAP, -1);
        AttemptHistory.Recent stats = history.recent(24, 65, 0.12);
        check(stats.attempts() == 2, "canceled/unconfirmed/overlap must not reduce success percentage");
        check(stats.placed() == 1 && stats.successPercent() == 50, "success rate");
        check(stats.rhythmPercent() == 50, "rhythm rate");
        check(stats.aimPercent() == 100, "aim rate");
        check(stats.mainFailure() == AttemptHistory.Outcome.MISS, "dominant failure");
        check(stats.meanSignedRhythmMs() == 42.5, "signed rhythm average");
        check(history.offsetMs(miss) == 20, "relative timestamp");

        // A later UI change must never rewrite the accuracy of old clicks.
        AttemptHistory criteriaHistory = new AttemptHistory();
        AttemptHistory.Entry original = criteriaHistory.begin(1_000_000_000L, 240, 4,
                12, true, true, 0);
        criteriaHistory.recordCriteria(original, 50, 0.12);
        criteriaHistory.recordAim(original, 0.5, 0.95, 0.10);
        criteriaHistory.resolve(original, AttemptHistory.Outcome.PLACED, 35);
        AttemptHistory.Recent strictAfterward = criteriaHistory.recent(24, 2, 0.01);
        check(strictAfterward.rhythmPercent() == 100 && strictAfterward.aimPercent() == 100,
                "changing settings later cannot invalidate previous good placement");
        AttemptHistory.Entry strictClick = criteriaHistory.begin(2_000_000_000L, 240, 4,
                12, true, true, 0);
        criteriaHistory.recordCriteria(strictClick, 2, 0.02);
        criteriaHistory.recordAim(strictClick, 0.5, 0.95, 0.10);
        criteriaHistory.resolve(strictClick, AttemptHistory.Outcome.PLACED, 30);
        AttemptHistory.Recent relaxedAfterward = criteriaHistory.recent(24, 100, 0.45);
        check(relaxedAfterward.rhythmPercent() == 50 && relaxedAfterward.aimPercent() == 50,
                "loosening settings later cannot retrofit bad clicks as good");

        try {
            Path dir = Files.createTempDirectory("godbridge-csv-test-");
            Path report = SessionExporter.export(history, dir);
            List<String> lines = Files.readAllLines(report);
            check(lines.size() == 7, "CSV has header plus six attempts");
            check(lines.get(0).contains("session_ms,result,bpm,subdivisions"), "CSV header");
            check(lines.get(1).contains(",PLACED,240,1,5,"), "CSV first result");
            check(lines.get(2).contains(",MISS,240,1,80,"), "CSV failure result");
            check(lines.get(4).contains(",TIMEOUT,240,4,0,"), "unconfirmed CSV is explicit");
            check(lines.get(5).contains(",OTHER_BLOCK,240,4,0,"), "unrelated block is not claimed");
            check(lines.get(6).contains(",OVERLAP,240,4,0,"), "overlap CSV remains visible");
            check(lines.get(0).endsWith("click_offset_ms,audio_offset_ms"), "both offset fields in CSV");
            check(lines.get(1).endsWith(",0,0"), "older callers retain zero offsets");
            Path report2 = SessionExporter.export(history, dir);
            check(!report.equals(report2), "report collision must not overwrite previous file");
        } catch (Exception ex) {
            throw new AssertionError("CSV export regression", ex);
        }

        // Snapshot independent audio and grading offsets for a recorded attempt.
        AttemptHistory offsetHistory = new AttemptHistory();
        AttemptHistory.Entry offsetClick = offsetHistory.begin(42L, 260, 4, 7, true,
                true, 1.0, 30, -20);
        check(offsetClick.clickOffsetMs == 30 && offsetClick.audioOffsetMs == -20,
                "offset snapshot retains distinct configurations");
        try {
            String csv = Files.readString(SessionExporter.export(offsetHistory,
                    Files.createTempDirectory("godbridge-offsets-")));
            check(csv.lines().skip(1).findFirst().orElseThrow().endsWith(",30,-20"),
                    "CSV keeps both offsets from when the button was pressed");
        } catch (Exception ex) {
            throw new AssertionError("Audio offset CSV regression", ex);
        }
        history.clear();
        for (int i = 0; i < AttemptHistory.CAPACITY + 88; i++) {
            AttemptHistory.Entry click = history.begin(10_000_000_000L + 100_000_000L * i,
                    240, 0, true, true, 0);
            history.resolve(click, i % 2 == 0 ? AttemptHistory.Outcome.PLACED : AttemptHistory.Outcome.MISS, -1);
        }
        check(history.snapshot().size() == AttemptHistory.CAPACITY, "bounded click history");
        check(history.snapshot().get(0).serial == 89, "oldest click removed without reordering");
        check(history.recent(24, 60, 0.15).successPercent() == 50, "last 24 only");
        check(TrainingAdvisor.recommend(history.recent(24, 60, 0.15), 240, 60)
                .contains("попадаешь"), "most common MISS feedback");
        history.clear();
        check(history.snapshot().isEmpty(), "session clear");
        System.out.println("AttemptHistorySelfTest PASS");
    }
}
