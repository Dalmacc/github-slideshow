#!/usr/bin/env bash
# Local build with a pinned, SHA-256-verified Gradle distribution.
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION=9.7.1
GRADLE_SHA256=acd53f1edaf02f1a8ff99879f8a34b302661a057d9b063ae9e35b552f804d20a
if ! command -v java >/dev/null 2>&1 || ! command -v javac >/dev/null 2>&1; then
  echo 'Java 25 JDK (both java and javac) is required. Set JAVA_HOME.' >&2
  exit 1
fi
java_version=$(java -version 2>&1 | sed -n "1p")
javac_version=$(javac -version 2>&1 | sed -n "1p")
if [[ ! "$java_version" =~ \"25([.\"]|$) ]] || [[ ! "$javac_version" =~ ^javac[[:space:]]25([.[:space:]]|$) ]]; then
  echo "JDK 25 is required; detected: $java_version / $javac_version" >&2
  exit 1
fi
if command -v gradle >/dev/null 2>&1; then
  gradle_exe=$(command -v gradle)
else
  gradle_exe="$(pwd)/.local-gradle/gradle-${GRADLE_VERSION}/bin/gradle"
  if [[ ! -x "$gradle_exe" ]]; then
    echo "Downloading and verifying Gradle ${GRADLE_VERSION}..."
    mkdir -p .local-gradle
    archive=".local-gradle/gradle-${GRADLE_VERSION}.zip"
    trap 'rm -f "$archive"' EXIT
    if command -v curl >/dev/null 2>&1; then
      curl -fL --retry 2 --connect-timeout 15 \
        "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "$archive"
    elif command -v wget >/dev/null 2>&1; then
      wget "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -O "$archive"
    else
      echo 'Install Gradle, curl or wget to build.' >&2; exit 1
    fi
    if command -v sha256sum >/dev/null 2>&1; then
      echo "$GRADLE_SHA256  $archive" | sha256sum -c -
    else
      echo "$GRADLE_SHA256  $archive" | shasum -a 256 -c -
    fi
    unzip -q "$archive" -d .local-gradle
    rm -f "$archive"
    trap - EXIT
  fi
fi
set -o pipefail
"$gradle_exe" --no-daemon --stacktrace clean build 2>&1 | tee gradle-build.log
jar_path='build/libs/godbridge-trainer-26.3-0.14.0.jar'
if [[ ! -f "$jar_path" ]]; then
  echo "Gradle finished, but the expected mod JAR was not found: $jar_path" >&2
  exit 1
fi
jar tf "$jar_path" | grep -qx 'fabric.mod.json'
jar tf "$jar_path" | grep -qx 'dev/dalmacc/godbridge/GodBridgeTrainerClient.class'
echo "JAR structure verified: $jar_path"
