# God Bridge Trainer 0.14.0 — отчёт проверки

Дата: 14 октября 2026. Статус: **только исходники; устанавливаемый Fabric `.jar` пока не получен.**

## Изменение

- После 350 мс без world-render frame метроном не пытается озвучивать старые доли; создаёт новое начало такта через один интервал между кликами.
- Применяются оба знака `audioOffsetMs`; сохранена независимая временная оценка физического клика.
- После восстановления `BeatConsistency` открывает новую серию, не обнуляя статистику сессии; трекеры CPS и подбора BPM исключают паузу из новых измерений.
- Счётчик восстановлений показан на HUD.

## Фактически выполненные проверки

- `bash scripts/verify-logic.sh` на Java 21: **15 PASS**. Новый `MetronomeRecoverySelfTest` проверяет 144 FPS, 10 FPS, паузу 350+ мс, смещения звука −200…+200 мс, отсутствие фантомной доли и ложного дублирования клика.
- `javac` **25 основных и 17 тестовых классов с временными Java-заглушками** игрового API: **PASS**. Заглушки проверяют лишь структуру Java и не являются библиотеками Minecraft/Fabric.
- Имитационный тест вызова `BridgeCoach.metronomeFrame` с поддельным `Minecraft`: `MetronomeStallStubSmoke PASS`. Проверены отсутствие преждевременного звукового слота, пересоздание origin и один запланированный импульс.
- `bash -n` для `build.sh`, `build-docker.sh`, `scripts/verify-logic.sh`: **PASS**.
- Сборочная версия 0.14.0 согласована в `gradle.properties`, `build.ps1`, `build.sh`, GitHub Actions и HUD.

## Настоящая сборка

Выполнен `bash build.sh`: **exit 1 на проверке JDK**:

```text
JDK 25 is required; detected: openjdk version "21.0.12.1" 2026-08-18 / javac 21.0.12.1
```

- Здесь отсутствуют Java 25, Docker, Gradle и разрешение DNS для Maven/Fabric.
- Gradle на реальных Minecraft/Fabric зависимостях **не запускался**; настоящего компиляторного лога нет.
- `.jar` не собран. Никакой игровой тест, включая F1/Alt-Tab и размещение блоков, не выполнялся.
- Ранее запуски GitHub Actions в пользовательском приватном `sandbox` завершались без выделения runner; этого недостаточно для проверки кода.

## Дальше

На Windows с доступом в интернет и JDK 25: `powershell -ExecutionPolicy Bypass -File .\build.ps1`.
Или с Docker Desktop: `powershell -ExecutionPolicy Bypass -File .\build-docker.ps1`.
Только после выхода `gradle clean build` 0 и проверки работы в Minecraft можно утверждать, что мод устанавливается и функционирует.
