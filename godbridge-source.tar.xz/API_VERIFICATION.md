# Проверка API для версии 0.13 (14 октября 2026)

Проверены опубликованные исходники/документация, но НЕ запуск Minecraft.

1. **Fabric API 0.162.0+26.3**: исходник
   `fabric-rendering-v1/src/client/java/net/fabricmc/fabric/api/client/rendering/v1/level/LevelRenderEvents.java`,
   тег `0.162.0+26.3`, репозиторий `FabricMC/fabric-api`.
   В нём объявлено поле `Event<EndMain> END_MAIN`, интерфейс
   `void endMain(LevelRenderContext context)`. Поэтому допустима регистрация
   `LevelRenderEvents.END_MAIN.register(context -> ...)`.
   URL:
   https://github.com/FabricMC/fabric-api/blob/0.162.0%2B26.3/fabric-rendering-v1/src/client/java/net/fabricmc/fabric/api/client/rendering/v1/level/LevelRenderEvents.java
2. **SDL ввод**: Fabric сообщает о замене GLFW на SDL и рекомендует
   использовать `InputConstants`, а не жёстко заданные коды кнопок:
   https://fabricmc.net/2026/09/15/263.html
3. Сигнатура `MouseHandler.onButton(long, MouseButtonInfo, int)` подтверждена
   опубликованной 26.3 Javadoc; актуальный Mixin целится в
   `onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V`.
   https://aldak.netlify.app/javadoc/26.3.x/net/minecraft/client/mousehandler
4. Проверена опубликованная дистрибуция Gradle 9.7.1 и её SHA-256:
   https://gradle.org/release-checksums/

**Пределы уверенности:** GitHub-исходники Fabric подтверждают существование
события и сигнатуру. Локальная компиляция с *самодельными* API-заглушками
не эквивалентна сборке с Minecraft 26.3. Она не проверяет реализацию,
Mixin-настройку, работу SDL или аудиопотока игры. Для финального статуса
нужен `gradle clean build` с Java 25 и запуск в Minecraft.
