package dev.dalmacc.godbridge;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3fc;

import java.util.Locale;

/** Training overlay for the 26.3 GUI extraction API. */
public final class TrainerHud {
    private static final int WHITE = 0xFFF5F8FF;
    private static final int DIM = 0xFFAFBBD5;
    private static final int GOOD = 0xFF75FFC3;
    private static final int BAD = 0xFFFF9B9B;
    private static final int WARM = 0xFFFFD36C;

    private TrainerHud() {}

    public static void draw(GuiGraphicsExtractor graphics, Minecraft mc, BridgeCoach coach) {
        if (!coach.active || mc.player == null || mc.gui.screen() != null) return;
        long now = System.nanoTime();
        // Metronome audio is driven by LevelRenderEvents.END_MAIN, not by this HUD.
        // The HUD switch only hides panels. The marker, metronome, and brief
        // feedback have independent toggles; users can practice with a clean
        // screen and still keep the Fortnite-like weak spot.
        if (coach.cfg.hud) {
            drawPanel(graphics, mc, coach, now);
            if (coach.cfg.heatmap && graphics.guiWidth() >= 440 && graphics.guiHeight() >= 210)
                drawHeatmap(graphics, mc, coach);
            drawAdvice(graphics, mc, coach);
        }
        if (coach.cfg.metronome) drawMetronome(graphics, mc, coach, now);
        if (coach.cfg.targetMarker) drawTarget(graphics, mc, coach, now);
        if (coach.cfg.feedback) drawFeedback(graphics, mc, coach, now);
    }

    private static void drawPanel(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c, long now) {
        if (g.guiWidth() < 650 || g.guiHeight() < 340) {
            drawCompactPanel(g, mc, c, now);
            return;
        }
        int x = 10;
        int y = 10;
        int width = 265;
        g.fill(x, y, x + width, y + 181, 0xBC09131F);
        g.fill(x, y, x + width, y + 2, GOOD);
        g.text(mc.font, "GOD BRIDGE TRAINER  |  v0.14", x + 10, y + 8, WHITE);
        g.text(mc.font, "Блоки: " + c.successfulBlocks + "   Серия: " + c.streak + " / " + c.bestStreak,
                x + 10, y + 25, DIM);
        g.text(mc.font, "Клики: " + c.rightClicks + "   CPS: " + c.recentCps(now) + " / " + c.peakCps,
                x + 10, y + 37, DIM);
        g.text(mc.font, "Ошибки: " + c.failedClicks + "   Неясно: " + c.unconfirmedClicks +
                "   Падения: " + c.falls, x + 10, y + 49, DIM);
        g.text(mc.font, "Рано: " + c.earlyClicks + "   Поздно: " + c.lateClicks +
                "   Ожид.: " + c.duplicateClicks, x + 10, y + 61, DIM);
        g.text(mc.font, String.format(Locale.ROOT, "Сред. откл. ритма: %.0f мс (32 клика)",
                c.meanAbsBeatErrorMs()), x + 10, y + 73, DIM);
        boolean diagonal = c.diagonalKeys(mc);
        g.text(mc.font, "Движение S + A/D: " + (diagonal ? "ДА" : "НЕТ"),
                x + 10, y + 85, diagonal ? GOOD : WARM);
        if (c.cfg.angleHint) {
            double error = c.angleError(mc);
            g.text(mc.font, String.format(Locale.ROOT, "Поворот к 45°: отклонение %.1f°", error),
                    x + 10, y + 97, error <= 9 ? GOOD : WARM);
        }
        AttemptHistory.Recent stats = c.recentStats();
        g.text(mc.font, "Последние " + stats.attempts() + ": успех " + stats.successPercent() + "%",
                x + 10, y + 113, stats.successPercent() >= 80 ? GOOD : DIM);
        if (stats.timed() > 0)
            g.text(mc.font, "Точные клики в ритм: " + stats.rhythmPercent() + "%",
                    x + 10, y + 125, stats.rhythmPercent() >= 75 ? GOOD : DIM);
        CadenceTracker.Snapshot cadence = c.recentCadence(now);
        String cadenceText = cadence.intervals() >= 3 ? String.format(Locale.ROOT,
                "Пальцы: %.1f CPS   Джиттер: %.0f мс", cadence.cps(), cadence.jitterMs())
                : "Пальцы: набери хотя бы 4 клика";
        g.text(mc.font, cadenceText, x + 10, y + 137, cadence.intervals() >= 3 ? DIM : WARM);
        // The rhythm metric is session-scoped; missed beats are measured only
        // within bursts, not across idle periods and menus.
        BeatConsistency.Snapshot rhythm = c.rhythmQuality();
        if (c.cfg.metronome && rhythm.uniqueSlots() > 0)
            g.text(mc.font, "Ритм: " + rhythm.hitPercent() + "%  пропуски: " + rhythm.missedBeats()
                    + "  серии: " + rhythm.bestStreak(), x + 10, y + 149, DIM);
        PulseDelivery.Snapshot delivery = c.pulseDelivery.snapshot();
        if (c.cfg.metronome && delivery.frameLimited())
            g.text(mc.font, "FPS: пропущено " + delivery.missPercent() + "% импульсов метронома",
                    x + 10, y + 161, WARM);
        else if (c.cfg.metronome && c.metronomeResyncs > 0)
            g.text(mc.font, "Возврат после фриза: " + c.metronomeResyncs + " раз",
                    x + 10, y + 161, DIM);
    }

    /** Fits beside, rather than on top of, the crosshair at 320–640 GUI pixels. */
    private static void drawCompactPanel(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c, long now) {
        int x = 6, y = 53, w = 148;
        g.fill(x, y, x + w, y + 102, 0xBC09131F);
        g.fill(x, y, x + w, y + 2, GOOD);
        g.text(mc.font, String.format(Locale.ROOT, "GB 0.14 ×%d  %.1f CPS",
                c.cfg.subdivisions, RhythmMath.targetCps(c.cfg.bpm, c.cfg.subdivisions)),
                x + 5, y + 7, WHITE);
        g.text(mc.font, "Бл: " + c.successfulBlocks + "   серия: " + c.streak,
                x + 5, y + 20, DIM);
        g.text(mc.font, "ПКМ: " + c.rightClicks + "  CPS: " + c.recentCps(now),
                x + 5, y + 33, DIM);
        g.text(mc.font, "Ош: " + c.failedClicks + "  ?: " + c.unconfirmedClicks + "  ожид: " + c.duplicateClicks,
                x + 5, y + 46, DIM);
        AttemptHistory.Recent stats = c.recentStats();
        g.text(mc.font, "Усп: " + stats.successPercent() + "%  ритм: " + stats.rhythmPercent() + "%",
                x + 5, y + 59, stats.successPercent() >= 80 ? GOOD : DIM);
        BeatConsistency.Snapshot rhythm = c.rhythmQuality();
        if (c.cfg.metronome && rhythm.uniqueSlots() > 0)
            g.text(mc.font, "Такт: " + rhythm.hitPercent() + "%  проп: " + rhythm.missedBeats(),
                    x + 5, y + 72, DIM);
        PulseDelivery.Snapshot delivery = c.pulseDelivery.snapshot();
        if (c.cfg.metronome && delivery.frameLimited())
            g.text(mc.font, "Метроном: пропуски " + delivery.missPercent() + "%",
                    x + 5, y + 85, WARM);
        else if (c.cfg.metronome && c.metronomeResyncs > 0)
            g.text(mc.font, "Паузы FPS: " + c.metronomeResyncs,
                    x + 5, y + 85, DIM);
    }

    private static void drawHeatmap(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c) {
        // A face-local map of the last 48 physical clicks. Green=placed, red=failed,
        // amber=waiting for the server/world to confirm.
        int width = 106;
        int x = g.guiWidth() > 414 ? g.guiWidth() - width - 10 : 10;
        int y = g.guiWidth() > 414 ? 10 : 158;
        int sx = x + 8;
        int sy = y + 19;
        int size = 90;
        g.fill(x, y, x + width, y + 120, 0xBC09131F);
        g.text(mc.font, "КЛИКИ НА ГРАНИ", x + 6, y + 5, WHITE);
        g.fill(sx, sy, sx + size, sy + size, 0xD91B2936);
        g.fill(sx, sy, sx + size, sy + 1, 0xFF60798C);
        g.fill(sx, sy + size - 1, sx + size, sy + size, 0xFF60798C);
        g.fill(sx, sy, sx + 1, sy + size, 0xFF60798C);
        g.fill(sx + size - 1, sy, sx + size, sy + size, 0xFF60798C);
        int guideX = sx + (int) Math.round(c.cfg.guideLateral * (size - 1));
        int guideY = sy + (int) Math.round((1 - c.cfg.guideHeight) * (size - 1));
        g.fill(guideX - 3, guideY - 1, guideX + 4, guideY + 2, WARM);
        g.fill(guideX - 1, guideY - 3, guideX + 2, guideY + 4, WARM);
        for (AimHistory.Sample hit : c.aimHistory.snapshot()) {
            int px = sx + 1 + (int) Math.round(hit.u * (size - 3));
            int py = sy + 1 + (int) Math.round((1 - hit.v) * (size - 3));
            int color = switch (hit.outcome()) {
                case PLACED -> GOOD;
                case FAILED -> BAD;
                case PENDING -> WARM;
                case CANCELED -> DIM;
            };
            g.fill(px - 1, py - 1, px + 2, py + 2, color);
        }
        g.text(mc.font, "Ближ. 48", x + 6, y + 109, DIM);
    }

    private static void drawMetronome(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c, long now) {
        int mx = g.guiWidth() / 2;
        int y = 18;
        int barWidth = 172;
        int x = mx - barWidth / 2;
        // The ruler represents ONE quarter note. Tick marks are true click
        // subdivisions (not four marks painted inside a single click interval).
        // The upper cursor is the assessment grid; the lower cursor is audio.
        double clickPhase = MetronomeTimeline.quarterPhase(now, c.beatOriginNs,
                c.cfg.bpm, c.cfg.subdivisions, c.cfg.beatOffsetMs);
        double audioPhase = MetronomeTimeline.quarterPhase(now, c.beatOriginNs,
                c.cfg.bpm, c.cfg.subdivisions, c.cfg.audioOffsetMs);
        g.fill(x - 4, y - 4, x + barWidth + 4, y + 33, 0xBD0B1320);
        g.fill(x, y + 13, x + barWidth, y + 20, 0xFF344152);
        g.fill(x, y + 13, x + (int) Math.round(barWidth * clickPhase), y + 20,
                clickPhase < 0.12 ? GOOD : 0xFF77A6ED);

        // Actual ±timing window, repeated once per requested click subdivision.
        long quarterNs = RhythmMath.clickPeriodNs(c.cfg.bpm, c.cfg.subdivisions) * c.cfg.subdivisions;
        double halfWindow = RhythmMath.effectiveToleranceMs(c.cfg.bpm,
                c.cfg.timingToleranceMs, c.cfg.subdivisions) * 1_000_000.0 / quarterNs;
        for (int i = 0; i < c.cfg.subdivisions; i++) {
            double center = i / (double) c.cfg.subdivisions;
            for (int wrap = -1; wrap <= 1; wrap++) {
                double lo = Math.max(0, center + wrap - halfWindow);
                double hi = Math.min(1, center + wrap + halfWindow);
                if (hi > lo) {
                    int left = x + (int) Math.floor(barWidth * lo);
                    int right = x + (int) Math.ceil(barWidth * hi);
                    g.fill(left, y + 19, right, y + 21, GOOD);
                }
            }
            int mark = x + (int) Math.round(barWidth * center);
            g.fill(mark, y + 11, mark + 1, y + 22, i == 0 ? WHITE : 0xFFC1CBD9);
        }
        int clickCursor = x + (int) Math.round(barWidth * clickPhase);
        int soundCursor = x + (int) Math.round(barWidth * audioPhase);
        g.fill(clickCursor - 1, y + 10, clickCursor + 2, y + 19, GOOD);
        // A separate lower audio pointer makes offset calibration visible.
        g.fill(soundCursor - 1, y + 23, soundCursor + 2, y + 28, WARM);
        String label = String.format(Locale.ROOT, "%d BPM ×%d = %.1f CPS",
                c.cfg.bpm, c.cfg.subdivisions,
                RhythmMath.targetCps(c.cfg.bpm, c.cfg.subdivisions));
        g.centeredText(mc.font, label, mx, y, WHITE);
    }

    private static void drawTarget(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach coach, long now) {
        GuideTarget target = coach.target;
        if (!mc.options.getCameraType().isFirstPerson()) return;
        if (target == null || !TargetFinder.stillVisible(mc, target)) {
            g.centeredText(mc.font, "Найди открытую боковую грань",
                    g.guiWidth() / 2, g.guiHeight() / 2 + 32, DIM);
            return;
        }
        Camera camera = mc.gameRenderer.mainCamera();
        if (!camera.isInitialized()) return;
        Vec3 offset = target.point().subtract(camera.position());
        Vector3fc forward = camera.forwardVector();
        double front = offset.x * forward.x() + offset.y * forward.y() + offset.z * forward.z();
        if (front <= 0.05) return;

        // Vanilla 26.3 projects through the actual camera matrix, accounting for
        // the current effective FOV. Coordinates returned are normalized (-1..1).
        Vec3 projected = mc.gameRenderer.projectPointToScreen(target.point());
        if (!Double.isFinite(projected.x) || !Double.isFinite(projected.y)) return;
        int cx = (int) Math.round((projected.x + 1.0) * 0.5 * g.guiWidth());
        int cy = (int) Math.round((1.0 - projected.y) * 0.5 * g.guiHeight());
        if (cx < 14 || cy < 14 || cx >= g.guiWidth() - 14 || cy >= g.guiHeight() - 14) return;

        double aimError = Double.POSITIVE_INFINITY;
        if (mc.hitResult instanceof BlockHitResult hit
                && hit.getBlockPos().equals(target.anchor()) && hit.getDirection() == target.face()) {
            aimError = GuideTarget.planarError(hit.getLocation(), target.anchor(), target.face(),
                    coach.cfg.guideLateral, coach.cfg.guideHeight);
        }
        boolean locked = aimError <= coach.cfg.aimTolerance;
        int tint = locked ? GOOD : WARM;
        int r = 10 + (int) (2.0 * Math.cos((now - coach.beatOriginNs) / 110_000_000.0));

        circle(g, cx, cy, r + 5, 0xB90A111B, 3);
        circle(g, cx, cy, r, tint, 2);
        cross(g, cx, cy, locked ? GOOD : WHITE);
        g.fill(cx - r - 8, cy - 1, cx - r - 3, cy + 1, tint);
        g.fill(cx + r + 3, cy - 1, cx + r + 8, cy + 1, tint);
        g.fill(cx - 1, cy - r - 8, cx + 1, cy - r - 3, tint);
        g.fill(cx - 1, cy + r + 3, cx + 1, cy + r + 8, tint);
        g.centeredText(mc.font, locked ? "ТОЧКА НАЙДЕНА" : "НАВЕДИ", cx, cy + r + 14,
                locked ? GOOD : WARM);
        if (!locked) {
            // The target is projected with the live camera matrix. Use the
            // screen-space delta to the reticle: face-local U flips for certain
            // normals and gives misleading arrows at oblique view angles.
            ScreenAimDirection.Cue cue = ScreenAimDirection.cue(cx, cy,
                    g.guiWidth() / 2.0, g.guiHeight() / 2.0, 6.0);
            String instruction = cue == ScreenAimDirection.Cue.CENTERED
                    ? "ПРОВЕРЬ ГРАНЬ" : cue.text();
            g.centeredText(mc.font, instruction, g.guiWidth() / 2,
                    g.guiHeight() / 2 + 28, WARM);
        }
    }

    private static void drawFeedback(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c, long now) {
        if (c.feedbackAgeMs(now) > 4_500 && c.rightClicks > 0) return;
        int center = g.guiWidth() / 2;
        int y = g.guiHeight() - 65;
        int w = Math.min(g.guiWidth() - 30, mc.font.width(c.feedback) + 26);
        g.fill(center - w / 2, y - 5, center + w / 2, y + 16, 0xBC09131F);
        g.centeredText(mc.font, c.feedback, center, y + 1, c.feedbackColor);
    }

    private static void drawAdvice(GuiGraphicsExtractor g, Minecraft mc, BridgeCoach c) {
        String text = c.coachingTip();
        int center = g.guiWidth() / 2;
        // This is an advisory, not a critical UI. Keep the center visible in a small window.
        if (mc.font.width(text) > g.guiWidth() - 34) return;
        int y = g.guiHeight() - 97;
        int half = (mc.font.width(text) + 26) / 2;
        g.fill(center - half, y - 4, center + half, y + 16, 0xB509131F);
        g.centeredText(mc.font, text, center, y + 2, DIM);
    }

    private static void cross(GuiGraphicsExtractor g, int x, int y, int color) {
        g.fill(x - 3, y, x + 4, y + 1, color);
        g.fill(x, y - 3, x + 1, y + 4, color);
    }

    private static void circle(GuiGraphicsExtractor g, int cx, int cy, int r, int color, int size) {
        for (int deg = 0; deg < 360; deg += 10) {
            double rad = Math.toRadians(deg);
            int x = cx + (int) Math.round(Math.cos(rad) * r);
            int y = cy + (int) Math.round(Math.sin(rad) * r);
            g.fill(x, y, x + size, y + size, color);
        }
    }
}
